# Jibi Story Seed Handoff — 2026-06-01

## Summary

- Handoff clusters: 13
- High priority: 2
- Medium priority: 11
- Editorial review: 11
- Needs more evidence: 2

## High Priority Story Seeds

### 1. AI 휴머노이드와 국가 산업정책

- Readiness: needs_more_evidence
- Priority: high
- Sources: infomax_manual
- Candidate count: 1
- Risk: low (-)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, policy_claim_risk
- First slide idea: 젠슨 황, 휴머노이드 로봇 공개…파트너사는 中 스타트업: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 공식자료/숫자 1개와 보조 기사 1개를 붙여 anny story seed로 검토

Why story:
- 휴머노이드 개발에 정부가 2030년까지 예산을 투입한다는 뉴스라, AI가 소프트웨어를 넘어 로봇·제조·국가 산업정책으로 번지는 장면을 보여줌

Known facts:
- 젠슨 황, 휴머노이드 로봇 공개…파트너사는 中 스타트업 (연합인포맥스)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 추가 독립 후보/출처 1개 이상

Suggested official sources:
- 과학기술정보통신부
- 산업통상자원부
- 국가연구개발사업 자료

Possible story angles:
- AI 산업정책이 로봇/제조로 확장되는 흐름
- 정부 R&D 예산과 민간 양산 사이의 간극
- 한국형 휴머노이드가 필요한 산업 현장

### 2. [영상] 15억짜리 미사일 대신…美, 1천만원대 저가무기로 드론 격추

- Readiness: needs_more_evidence
- Priority: high
- Sources: yonhap_international_rss_candidate
- Candidate count: 1
- Risk: low (-)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source
- First slide idea: [영상] 15억짜리 미사일 대신…美, 1천만원대 저가무기로 드론 격추: 핵심 수치/추세를 한 장 chart로 먼저 보여주기
- Next action: 공식자료/숫자 1개와 보조 기사 1개를 붙여 anny story seed로 검토

Why story:
- 값싼 드론 하나를 막기 위해 수백만 달러짜리 미사일을 태우는 구조라, 전쟁이 무기 성능보다 비용 교환비 싸움으로 바뀌는 장면을 보여줌

Known facts:
- [영상] 15억짜리 미사일 대신…美, 1천만원대 저가무기로 드론 격추 (연합뉴스 세계)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 우크라이나/중동 전장에서 드론이 비용 구조를 바꾼 사례
- 싼 공격 수단을 비싼 미사일로 막는 방어자 딜레마
- 레이저/전자전/그물총 같은 저비용 대응책 경쟁

## Medium Priority Story Seeds

### 1. 금리/자산가격 스트레스와 거시 리스크

- Readiness: editorial_review
- Priority: medium
- Sources: guardian_business, guardian_technology, infomax_manual, yonhap_economy, yonhap_international_rss_candidate
- Candidate count: 14
- Risk: medium (corporate_promo_risk, investment_advice_risk)
- Quality flags: investment_risk_cluster, multi_candidate_cluster, official_evidence_missing, single_company_frame
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, market_claim_risk, policy_claim_risk
- First slide idea: What can the Dutch teach the UK about how to tackle the youth jobs crisis?: 핵심 수치/추세를 한 장 chart로 먼저 보여주기
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 금리·환율·자산가격 움직임 하나로 끝내면 투자 뉴스에 가깝지만, AI 투자 비용과 장기금리 압박이 맞물리는지 확인할 가치가 있음

Known facts:
- What can the Dutch teach the UK about how to tackle the youth jobs crisis? (The Guardian Business)
- 목포상의 "중동사태로 지역기업 매출 급감…정부지원 절실" (연합뉴스 경제)
- [외환] 원/달러 환율 0.9원 오른 1,508.8원(개장) (연합뉴스 경제)
- 한투증권, '일본 엔화로 단기투자' RP 판매 (연합뉴스 경제)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 투자 조언으로 읽히지 않도록 반대 근거와 리스크

Suggested official sources:
- 한국은행
- 미국 재무부/FRED
- 금융시장 통계

Possible story angles:
- 장기금리 상승과 성장주/AI 투자 할인율
- 채권시장 스트레스와 기업 자금조달 비용
- 투자 조언을 피하는 거시 구조 설명

### 2. AI 공급망 투자와 단일 기업 자금조달

- Readiness: editorial_review
- Priority: medium
- Sources: hankyung_manual, infomax_manual, yonhap_economy
- Candidate count: 4
- Risk: medium (corporate_promo_risk, investment_advice_risk)
- Quality flags: investment_risk_cluster, multi_candidate_cluster, official_evidence_missing, single_company_frame
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, market_claim_risk
- First slide idea: [1보] 5월 수출 878억달러로 53%↑…월 기준 역대 최대: 핵심 수치/추세를 한 장 chart로 먼저 보여주기
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 단일 기업 유상증자 뉴스로 끝내면 약하지만, 글라스기판 투자와 AI 반도체 공급망 자금조달이라는 구조로 묶을 수 있는지 확인할 필요가 있음

Known facts:
- [1보] 5월 수출 878억달러로 53%↑…월 기준 역대 최대 (연합뉴스 경제)
- [게시판] KB국민, 해외특화상품 'KB NEED Global 카드' 출시 (연합뉴스 경제)
- HL디앤아이한라, 1분기 영업익 34%↑…수주잔고 6.2조원 (연합인포맥스)
- "서초동 1000대 1인데 미아동은 4대 1"…서울 청약도 양극화 [돈앤톡] (한국경제)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 투자 조언으로 읽히지 않도록 반대 근거와 리스크

Suggested official sources:

Possible story angles:
- 글라스기판 투자와 AI 반도체 공급망
- 신성장 설비투자 자금조달 부담
- 단일 기업 홍보/투자 조언으로 읽히지 않는 안전한 프레임

### 3. 굽네치킨, 순살 메뉴 중량 800→700ｇ…수급 불안 장기화 여파

- Readiness: editorial_review
- Priority: medium
- Sources: yonhap_economy
- Candidate count: 1
- Risk: high (medical_claim_risk)
- Quality flags: official_evidence_missing
- Slideability: score=0.74, visual=high, proof=chart, source_card, risks=-
- First slide idea: 굽네치킨, 순살 메뉴 중량 800→700ｇ…수급 불안 장기화 여파: 원문 source card로 시작해 쟁점 질문 제시
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 의학적 치료 주장보다 병원 운영·연락·배정 같은 workflow를 AI가 바꾸는 사례라, 의료 리스크를 조심하면서도 현장 운영 혁신으로 설명 가능

Known facts:
- 굽네치킨, 순살 메뉴 중량 800→700ｇ…수급 불안 장기화 여파 (연합뉴스 경제)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 의학적 주장 검증용 공식/전문 출처

Suggested official sources:

Possible story angles:
- 병원 연락·배정·예약 workflow 자동화
- 의료 인력 부족과 운영 병목
- 의학적 효능 주장을 피하는 운영 개선 프레임

### 4. [제2026-10호｣ 우리나라 주식 자산효과에 대한 평가

- Readiness: editorial_review
- Priority: medium
- Sources: bok
- Candidate count: 1
- Risk: medium (investment_advice_risk)
- Quality flags: investment_risk_cluster, official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, market_claim_risk, policy_claim_risk
- First slide idea: [제2026-10호｣ 우리나라 주식 자산효과에 대한 평가: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 한국은행 이슈노트형 연구자료라 단발 뉴스보다 숫자, 작동 메커니즘, 한국 경제/생활과 이어지는 정책 함의를 함께 볼 수 있음

Known facts:
- [제2026-10호｣ 우리나라 주식 자산효과에 대한 평가 (한국은행)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 투자 조언으로 읽히지 않도록 반대 근거와 리스크
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 보고서가 제시한 핵심 숫자와 추세
- 그 숫자가 생긴 경제/산업 메커니즘
- 한국 정책·가계·기업 의사결정으로 이어지는 지점

### 5. [제2025-34호] 지속가능한 주민참여형 재생에너지 사업 발전 방안

- Readiness: editorial_review
- Priority: medium
- Sources: bok
- Candidate count: 1
- Risk: medium (investment_advice_risk)
- Quality flags: investment_risk_cluster, official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, market_claim_risk, policy_claim_risk
- First slide idea: [제2025-34호] 지속가능한 주민참여형 재생에너지 사업 발전 방안: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 연구노트가 현상 진단에서 정책 과제까지 이어지는 구조라, 숫자 근거와 제도 설계를 한 장의 설명 카드로 만들 수 있음

Known facts:
- [제2025-34호] 지속가능한 주민참여형 재생에너지 사업 발전 방안 (한국은행)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 투자 조언으로 읽히지 않도록 반대 근거와 리스크
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 연구노트의 문제 진단과 핵심 통계
- 제도/정책 변화가 필요한 메커니즘
- 한국 시청자가 체감할 수 있는 비용·기회·리스크

### 6. [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박

- Readiness: editorial_review
- Priority: medium
- Sources: korea_policy_briefing
- Candidate count: 1
- Risk: high (crime_or_drug_sensitivity, medical_claim_risk)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, policy_claim_risk
- First slide idea: [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 공식 보도자료지만 숫자, 생활 영향, 산업 메커니즘, 규제 갈등 중 하나 이상이 있어 evidence를 넘어 seed 후보로 검토할 가치가 있음

Known facts:
- [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박 (정책브리핑)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 의학적 주장 검증용 공식/전문 출처
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 보도자료의 핵심 수치 또는 정책 변화
- 산업/가계/시장에 실제로 닿는 메커니즘
- 공식자료를 시각화할 수 있는 표·지도·전후 비교

### 7. [보건복지부]'범부처 총력 대응'으로 마약 근절 전방위 압박

- Readiness: editorial_review
- Priority: medium
- Sources: korea_policy_briefing
- Candidate count: 1
- Risk: high (crime_or_drug_sensitivity, medical_claim_risk)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, policy_claim_risk
- First slide idea: [보건복지부]'범부처 총력 대응'으로 마약 근절 전방위 압박: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 공식 보도자료지만 숫자, 생활 영향, 산업 메커니즘, 규제 갈등 중 하나 이상이 있어 evidence를 넘어 seed 후보로 검토할 가치가 있음

Known facts:
- [보건복지부]'범부처 총력 대응'으로 마약 근절 전방위 압박 (정책브리핑)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 의학적 주장 검증용 공식/전문 출처
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 보도자료의 핵심 수치 또는 정책 변화
- 산업/가계/시장에 실제로 닿는 메커니즘
- 공식자료를 시각화할 수 있는 표·지도·전후 비교

### 8. [조달청]국민주권정부 1주년, 기술선도·균형·공정성장을 이끄는 공공조달 개혁 성과

- Readiness: editorial_review
- Priority: medium
- Sources: korea_policy_briefing
- Candidate count: 1
- Risk: medium (corporate_promo_risk)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, policy_claim_risk
- First slide idea: [조달청]국민주권정부 1주년, 기술선도·균형·공정성장을 이끄는 공공조달 개혁 성과: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 공식 보도자료지만 숫자, 생활 영향, 산업 메커니즘, 규제 갈등 중 하나 이상이 있어 evidence를 넘어 seed 후보로 검토할 가치가 있음

Known facts:
- [조달청]국민주권정부 1주년, 기술선도·균형·공정성장을 이끄는 공공조달 개혁 성과 (정책브리핑)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 추가 독립 후보/출처 1개 이상
- 다른 source의 보조 기사

Suggested official sources:

Possible story angles:
- 보도자료의 핵심 수치 또는 정책 변화
- 산업/가계/시장에 실제로 닿는 메커니즘
- 공식자료를 시각화할 수 있는 표·지도·전후 비교

### 9. W컨셉, 오클리·메타 협업 'AI 스마트 글래스' 한정 판매

- Readiness: editorial_review
- Priority: medium
- Sources: yonhap_industry
- Candidate count: 1
- Risk: medium (corporate_promo_risk)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data
- First slide idea: W컨셉, 오클리·메타 협업 'AI 스마트 글래스' 한정 판매: platform_labor_market 관점의 질문형 title slide
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 플랫폼의 수수료·배달비·상인/노동자 부담 논쟁이라, 앱 편의성 뒤의 비용 배분과 노동시장 구조를 보여줄 수 있음

Known facts:
- W컨셉, 오클리·메타 협업 'AI 스마트 글래스' 한정 판매 (연합뉴스 산업)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 숫자/통계 또는 공식 자료
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 플랫폼 무료/할인 경쟁의 비용 전가 구조
- 가맹점·노동자·소비자 사이의 부담 배분
- 한국 배달/플랫폼 시장의 수수료 논쟁

### 10. [공정거래위원회]트립닷컴 트래블 싱가포르 프라이빗 리미티드 및 (주)트립닷컴코리아의 전자상거래법 위반행위 제재

- Readiness: editorial_review
- Priority: medium
- Sources: korea_policy_briefing
- Candidate count: 1
- Risk: medium (investment_advice_risk)
- Quality flags: investment_risk_cluster, official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, market_claim_risk, policy_claim_risk
- First slide idea: [공정거래위원회]트립닷컴 트래블 싱가포르 프라이빗 리미티드 및 (주)트립닷컴코리아의 전자상거래법 위반행위 제재: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 공식 보도자료지만 숫자, 생활 영향, 산업 메커니즘, 규제 갈등 중 하나 이상이 있어 evidence를 넘어 seed 후보로 검토할 가치가 있음

Known facts:
- [공정거래위원회]트립닷컴 트래블 싱가포르 프라이빗 리미티드 및 (주)트립닷컴코리아의 전자상거래법 위반행위 제재 (정책브리핑)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 투자 조언으로 읽히지 않도록 반대 근거와 리스크
- 추가 독립 후보/출처 1개 이상

Suggested official sources:

Possible story angles:
- 보도자료의 핵심 수치 또는 정책 변화
- 산업/가계/시장에 실제로 닿는 메커니즘
- 공식자료를 시각화할 수 있는 표·지도·전후 비교

### 11. Scientists have scrapped the worst-case climate scenario – because action is making a difference

- Readiness: editorial_review
- Priority: medium
- Sources: the_conversation
- Candidate count: 1
- Risk: high (political_sensitivity)
- Quality flags: official_evidence_missing
- Slideability: score=1.0, visual=high, proof=diagram, chart, source_card, risks=single_source, needs_official_data, policy_claim_risk
- First slide idea: Scientists have scrapped the worst-case climate scenario – because action is making a difference: 구조 diagram으로 시작하고 핵심 숫자는 보조 chart로 확인
- Next action: 리스크 프레이밍을 확인한 뒤 보조 근거를 추가

Why story:
- 학술/해설형 기사라 단일 기업 뉴스로 소비하기보다 과학, 사회, 정책, 환경 리스크가 왜 생겼는지를 구조적으로 설명하는 seed로 볼 수 있음

Known facts:
- Scientists have scrapped the worst-case climate scenario – because action is making a difference (The Conversation)

Missing evidence:
- 원문 기사 링크
- 추가 독립 출처 1개 이상
- 추가 독립 후보/출처 1개 이상
- 다른 source의 보조 기사

Suggested official sources:

Possible story angles:
- 기사의 설명 대상이 되는 과학/사회 메커니즘
- 정책·시장·생활 리스크로 이어지는 연결고리
- 한국 사례와 비교할 수 있는 증거 카드

## Generated Bundle Target

- /Users/bae/Documents/code/luddite/data/candidates/anny_input_bundles.jsonl
- Run `make build-anny-input-bundles` to refresh the structured anny input bundles.

