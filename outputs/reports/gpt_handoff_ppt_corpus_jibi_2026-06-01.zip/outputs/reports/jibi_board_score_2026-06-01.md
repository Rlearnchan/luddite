# Jibi Board Score Report — 2026-06-01

Report-only review-board scoring layer. This does not change the visible sheet schema.

- use_board_score: false
- use_topic_diversity: false
- selected_count: 10
- recommended_visible_board_size: 9
- strong_candidate_count: 0
- sub_block_count: 9
- hook_only_count: 0
- evidence_backfill_count: 0
- fixed_10_backfill_used: true
- mismatch_guarded_count: 0
- reviewed_suppressed_count: 3
- hard_blocked_count: 27
- needs_second_source_count: 0
- support_missing_count: 2

## Selected Board Candidates

| title | total_score | board_score | source_role | story_role | seed_quality | editorial_role | selection_bucket | selected reasons | risks |
| --- | ---: | ---: | --- | --- | --- | --- | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 71.4 | 85.4 | section_news | seed_with_supporting_links | bundle_needed | sub_block | primary_fit | base_total_score=71.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +2 syuka_adjacent_context; +2 possible_angle_shift | - |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 50.6 | 58.6 | academic_explainer | seed_with_supporting_links | bundle_needed | sub_block | primary_fit | base_total_score=50.6; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 lesson_past_syuka_overlap_needs_new_angle | - |
| 공공/현장 AI 도입과 책임 | 65.4 | 61.4 | public_wire | seed_with_supporting_links | bundle_needed | sub_block | primary_fit | base_total_score=65.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; -18 weak_audience_bridge; +6 strong_angle_shift | - |
| 플랫폼 무료배달 / 수수료 비용 배분 | 64 | 89 | public_wire | seed_with_supporting_links | bundle_needed | sub_block | primary_fit | base_total_score=64; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +6 strong_angle_shift; +5 lesson_platform_hidden_cost_bonus | - |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 39.6 | 47.6 | section_news | seed_with_supporting_links | bundle_needed | sub_block | primary_fit | base_total_score=39.6; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 lesson_past_syuka_overlap_needs_new_angle | - |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | 61 | 41 | section_news | seed_with_supporting_links | conditional_seed | sub_block | primary_fit | base_total_score=61; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; -30 generic_frame_high_risk | - |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 71.4 | 49.4 | market_wire | seed_with_supporting_links | conditional_seed | sub_block | primary_fit | base_total_score=71.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 generic_frame_high_risk | - |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | 64 | 44 | public_wire | seed_with_supporting_links | conditional_seed | sub_block | primary_fit | base_total_score=64; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; -30 generic_frame_high_risk | - |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | 64 | 44 | section_news | seed_with_supporting_links | conditional_seed | sub_block | role_cap_backfill | base_total_score=64; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; -30 generic_frame_high_risk | - |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 61 | 0 | section_news | seed_with_supporting_links | conditional_seed | evidence | role_cap_backfill | base_total_score=61; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; -30 generic_frame_high_risk; -60 lesson_sports_primary_downrank | - |

## Suppressed High Total Score Candidates

| title | total_score | board_score | why excluded | reviewed history |
| --- | ---: | ---: | --- | --- |
| 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 76 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 71.4 | 96.4 | source_role_cap_overflow | - |
| 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 71.4 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 70.6 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 68.4 | 6.4 | reviewed_history_suppressed | promoted_before |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 67 | 0 | reviewed_history_suppressed, generic_frame_downrank | rejected_before |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 67 | 49 | source_role_cap_overflow, generic_frame_downrank | - |
| 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 67 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 67 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 65 | 57 | evidence_or_background_backfill | - |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 64 | 23 | reviewed_history_suppressed, generic_frame_downrank | reviewed_before |
| [제2026-4호] 첨단 바이오헬스 산업 육성방안: 바이오 데이터 활용 기반 구축을 중심으로 | 64 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank | - |
| "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범 | 64 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| "고성능 AI 보안 위협 막자"…금융위, 민간 기술자문단 가동 | 64 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank, generic_frame_downrank | - |
| Are robots nearing their ChatGPT moment? – podcast | 64 | 44 | source_role_cap_overflow, generic_frame_downrank | - |
| If you want to run your first marathon in your 50s, it helps to be chased by zombies | 64 | 44 | source_role_cap_overflow, generic_frame_downrank | - |
| Our tech overlords are planning for conscious AI to conquer the cosmos. What could go wrong? / Eduardo Porter | 64 | 44 | source_role_cap_overflow, generic_frame_downrank | - |
| Put a £5 deposit on vapes to stop littering, say waste companies | 64 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank | - |
| [BOK 컨퍼런스] IMF 국장 "통화정책, 물가뿐 아니라 금융취약성도 고려해야"(종합) | 64 | 48 | source_role_cap_overflow, generic_frame_downrank | - |
| [천안소식] 갤러리아 센터시티 패션 브랜드 '위글위글' 오픈 | 64 | 0 | story_role=demote_or_reject, seed_quality=reject_or_downrank | - |

## Reviewed Candidate Suppression

| title | previous date | status | reviewers | required action | excerpt |
| --- | --- | --- | --- | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 2026-05-25 | promoted_before | 형찬 | avoid_duplicate_review_unless_followup_news_changed | 자료는 조금 다르지만 청년 노동시장 주제, 특히 쉬었음 소재는 많이 다룬 바 있음. 최근 영상 제목으로는 "83~95년생의 삶을 추적해봤습니다.", "이제 근로소득으로는 부자가 될 수 없나" 정도가 있음. 즉, 좋... |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 2026-05-27 | reviewed_before | 동찬 | use_second_search_or_new_frame_before_reposting | 슈카월드는 경제학 교과서 채널이 아니야. |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 2026-05-25 | rejected_before | 형찬 | do_not_repost_without_new_hook_or_explicit_override | 이것도 재미가 없을 듯함. seed로 보기에는 약함. 조각투자를 교과서처럼 설명하면, "그래서 뭐" 반응이 나올 것임. |

## Reviewed Candidate Reconsideration Queue

| title | total_score | board_score | second-search links | query types | status |
| --- | ---: | ---: | ---: | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 68.4 | 6.4 | 1 | - | not_reconsidered_promoted_before_wait_for_followup_news |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 64 | 23 | 0 | - | not_reconsidered_needs_second_search_or_new_hook |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 67 | 0 | 0 | - | not_reconsidered_rejected_before_without_new_hook |

## Board Mismatch Guard

| visible title | primary metadata title | source | story_fingerprint | mismatch reason | required action |
| --- | --- | --- | --- | --- | --- |
| none | none | none | none | none | none |

## Hard Blocked

| title | source | reasons |
| --- | --- | --- |
| [제2026-4호] 첨단 바이오헬스 산업 육성방안: 바이오 데이터 활용 기반 구축을 중심으로 | 한국은행 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범 | 연합뉴스 경제 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| "고성능 AI 보안 위협 막자"…금융위, 민간 기술자문단 가동 | 연합인포맥스 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 연합뉴스 세계 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| "이란, 챗GPT·제미나이로 사이버전…악성코드 개발·피싱 공격" | 연합뉴스 세계 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| [부고] 전종윤(유진투자증권 브랜드전략팀장)씨 모친상 | 연합인포맥스 | obituary_or_personnel_notice, story_role=demote_or_reject, seed_quality=reject_or_downrank |
| [천안소식] 갤러리아 센터시티 패션 브랜드 '위글위글' 오픈 | 연합뉴스 경제 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| [특징주] '젠슨 황 효과'에 LG그룹주 급등세 지속 | 연합뉴스 경제 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 과기부 홈페이지도 AI 시대…'AI 친화형' 전면 개편 | 연합뉴스 산업 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 네이버 AI 쇼핑 에이전트, 이용자에게 먼저 상품 제안한다 | 연합뉴스 산업 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 연합뉴스 세계 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 마이크론 '1조달러' 진입에 美서도 AI 거품논란 재점화 | 연합뉴스 세계 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 복지장관 "바이오특구 중심 규제특례 도입해 기업투자 활성화" | 연합뉴스 산업 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 엔비디아, 차세대 AI 플랫폼 '베라 루빈' 양산 돌입 | 연합인포맥스 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 젠슨 황 "베라 루빈 전면 생산 중"…AI 에이전트 겨냥 CPU 강조 | 연합뉴스 산업 | story_role=demote_or_reject, seed_quality=reject_or_downrank |
| 젠슨 황, AI 노트북 시장 진출 선언…삼성·SK 메모리 탑재 유력(종합) | 연합뉴스 산업 | story_role=demote_or_reject, seed_quality=reject_or_downrank |

## Topic Diversity

- use_topic_diversity: false
- constrained_families: ai_tech
- selected_topic_family_counts: {"ai_tech": 5, "consumer_life": 3, "culture_media": 1, "energy_climate": 4, "global_conflict": 2, "industry_supply_chain": 3, "labor_work": 2, "markets_finance": 2, "policy_government": 3}
- selected_primary_topic_counts: {"ai_tech": 2, "consumer_life": 1, "energy_climate": 4, "global_conflict": 1, "labor_work": 1, "policy_government": 1}
- warnings: topic_overconcentration:ai_tech=5/10, topic_overconcentration:energy_climate=4/10, primary_topic_overconcentration:energy_climate=4/10

| title | board_score | primary topic | topic families | diversity penalty |
| --- | ---: | --- | --- | ---: |
| 에너지 가격 충격 / 전기요금 / 생활비 | 85.4 | energy_climate | consumer_life, culture_media, energy_climate, global_conflict, industry_supply_chain, policy_government | 0 |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 58.6 | energy_climate | energy_climate, industry_supply_chain | 0 |
| 공공/현장 AI 도입과 책임 | 61.4 | policy_government | ai_tech, policy_government | 0 |
| 플랫폼 무료배달 / 수수료 비용 배분 | 89 | consumer_life | consumer_life, labor_work, markets_finance, policy_government | 0 |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 47.6 | energy_climate | energy_climate, industry_supply_chain | 0 |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | 41 | ai_tech | ai_tech | 0 |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 49.4 | labor_work | ai_tech, consumer_life, labor_work, markets_finance | 0 |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | 44 | energy_climate | energy_climate | 0 |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | 44 | ai_tech | ai_tech | 0 |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 0 | global_conflict | ai_tech, global_conflict | 0 |

## Angle Lab

- generic_frame_count: 40
- frame_shift_count: 8

### Generic Frame Downranks

| title | total_score | board_score | risk | reasons |
| --- | ---: | ---: | --- | --- |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 64 | 23 | high | generic_export_or_growth_question, no_specific_scene, no_mechanism_shift, no_frame_shift |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 67 | 0 | high | abstract_policy_support_question, generic_export_or_growth_question, no_specific_scene, no_frame_shift |
| "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범 | 64 | 0 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| "고성능 AI 보안 위협 막자"…금융위, 민간 기술자문단 가동 | 64 | 0 | high | broad_ai_topic, abstract_policy_support_question, no_specific_scene, no_mechanism_shift, no_frame_shift |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 70.6 | 0 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| "이란, 챗GPT·제미나이로 사이버전…악성코드 개발·피싱 공격" | 61 | 0 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | 61 | 41 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | 64 | 44 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 61 | 0 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Are robots nearing their ChatGPT moment? – podcast | 64 | 44 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 71.4 | 49.4 | high | broad_ai_topic, generic_export_or_growth_question, no_specific_scene, no_mechanism_shift, no_frame_shift |
| If you want to run your first marathon in your 50s, it helps to be chased by zombies | 64 | 44 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| On-street EV charging in UK is postcode lottery as drivers face council objections | 61 | 41 | high | generic_energy_price_question, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Our tech overlords are planning for conscious AI to conquer the cosmos. What could go wrong? / Eduardo Porter | 64 | 44 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 67 | 49 | high | broad_ai_topic, no_specific_scene, no_mechanism_shift, no_frame_shift |

### Frame Shift Candidates

| title | board_score | angle_score | frame option | needs |
| --- | ---: | ---: | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 6.4 | 5 | 회사 막내가 사라질 때 조직은 누구를 어떻게 키우나 | 신입 교육 비용, 직무별 AI 대체 사례, 기업 규모별 채용 변화 |
| 플랫폼 무료배달 / 수수료 비용 배분 | 89 | 5 | 공짜처럼 보이는 배달비는 누구의 손익계산서로 이동하나 | 수수료율, 점주 마진, 소비자 가격 전가 사례 |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 57 | 5 | 생활 불편에 가격표가 붙으면 이웃 갈등은 시장 문제가 된다 | 소음 규제, 분쟁 사례, 비용 산정 방식 |
| 공공/현장 AI 도입과 책임 | 61.4 | 4 | AI가 행정 판단에 들어오면 책임은 사람과 시스템 중 어디에 남나 | 공공 AI 가이드라인, 오판·감사 사례, 기관별 책임 규정 |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 96.4 | 4 | AI가 행정 판단에 들어오면 책임은 사람과 시스템 중 어디에 남나 | 공공 AI 가이드라인, 오판·감사 사례, 기관별 책임 규정 |
| 에너지 가격 충격 / 전기요금 / 생활비 | 85.4 | 3 | 전쟁과 연료비는 어떤 경로로 집 전기요금이 되나 | 연료비 연동 구조, 가계 전기요금, 산업용 전력 가격 |
| [제2026-4호] 첨단 바이오헬스 산업 육성방안: 바이오 데이터 활용 기반 구축을 중심으로 | 0 | 3 | 특허를 읽는 비용이 낮아지면 중소기업도 기술 지형을 볼 수 있나 | 이용 대상, 검색 데이터 범위, 민간 특허분석 서비스 비교 |
| 과기부 홈페이지도 AI 시대…'AI 친화형' 전면 개편 | 0 | 3 | 특허를 읽는 비용이 낮아지면 중소기업도 기술 지형을 볼 수 있나 | 이용 대상, 검색 데이터 범위, 민간 특허분석 서비스 비교 |

## Review-Derived Board Adjustments

| title | total_score | board_score | roles | adjustments | reasons |
| --- | ---: | ---: | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 71.4 | 85.4 | sub_block | - | +6 strong_so_what; +2 syuka_adjacent_context; +2 possible_angle_shift; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 68.4 | 6.4 | sub_block | - | -6 review_sub_block_not_primary; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk; -6 lesson_support_missing; -35 promoted_before |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 50.6 | 58.6 | sub_block | - | +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 64 | 23 | suppress | - | base_total_score=64; +8 standalone_seed; +6 strong_so_what; -30 generic_frame_high_risk; -25 reviewed_before |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 67 | 0 | sub_block, suppress | - | +2 possible_angle_shift; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk; -6 lesson_support_missing; -80 rejected_before |
| 플랫폼 무료배달 / 수수료 비용 배분 | 64 | 89 | sub_block | - | +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +6 strong_angle_shift; +5 lesson_platform_hidden_cost_bonus |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 70.6 | 0 | sub_block | - | -18 weak_audience_bridge; -8 public_wire_other_needs_clear_system_frame; -30 generic_frame_high_risk; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 39.6 | 47.6 | sub_block | - | +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 61 | 0 | suppress | sports_primary_downrank | +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; -30 generic_frame_high_risk; -60 lesson_sports_primary_downrank |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 71.4 | 49.4 | sub_block | - | +2 conditional_so_what; +2 syuka_adjacent_context; -30 generic_frame_high_risk; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| Put a £5 deposit on vapes to stop littering, say waste companies | 64 | 0 | sub_block | - | base_total_score=64; -60 demote_or_reject; -18 weak_audience_bridge; -8 public_wire_other_needs_clear_system_frame; -4 lesson_syuka_similarity_false_positive_risk |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 67 | 49 | sub_block | - | +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context; -30 generic_frame_high_risk; -30 lesson_past_syuka_overlap_needs_new_angle |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 65 | 57 | sub_block | - | +2 syuka_adjacent_context; -18 evidence_only; +6 strong_angle_shift; -30 lesson_past_syuka_overlap_needs_new_angle; -4 lesson_syuka_similarity_false_positive_risk |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 71.4 | 96.4 | sub_block | - | +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +6 strong_angle_shift; +5 lesson_platform_hidden_cost_bonus |

## Selection Lessons

| title | before | after | role | lessons | support requirements | why not main seed |
| --- | ---: | ---: | --- | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 89.4 | 85.4 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 51.4 | 6.4 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check; support missing: 과거 영상과 다른 새 각도 |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 62.6 | 58.6 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 55 | 0 | suppress | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check; support missing: 과거 영상과 다른 새 각도 |
| 플랫폼 무료배달 / 수수료 비용 배분 | 84 | 89 | sub_block | platform_hidden_cost_bonus | policy_or_stat | needs supporting links, tighter frame, or main-story host |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 0 | 0 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 51.6 | 47.6 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 41 | 0 | suppress | sports_primary_downrank | - | sports topic is weak as the primary story |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 53.4 | 49.4 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Put a £5 deposit on vapes to stop littering, say waste companies | 0 | 0 | sub_block | syuka_similarity_false_positive_risk | - | past-video match appears broad and needs human duplicate check |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 49 | 49 | sub_block | past_syuka_overlap_needs_new_angle | past_video_new_angle | past Syuka overlap means main seed needs a new angle |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 61 | 57 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | evidence_or_background_record |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 91.4 | 96.4 | sub_block | platform_hidden_cost_bonus | policy_or_stat | needs supporting links, tighter frame, or main-story host |

## Support Missing Queue

| title | board_score | missing support | status |
| --- | ---: | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 6.4 | past_video_new_angle | missing |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 0 | past_video_new_angle | missing |

## Hook/Sub-block Queue

| title | board_score | role | suggested use |
| --- | ---: | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 85.4 | sub_block | one_page_sub_block |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 6.4 | sub_block | one_page_sub_block |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 58.6 | sub_block | one_page_sub_block |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 0 | sub_block, suppress | one_page_sub_block |
| 플랫폼 무료배달 / 수수료 비용 배분 | 89 | sub_block | one_page_sub_block |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 0 | sub_block | one_page_sub_block |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 47.6 | sub_block | one_page_sub_block |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 49.4 | sub_block | one_page_sub_block |
| Put a £5 deposit on vapes to stop littering, say waste companies | 0 | sub_block | one_page_sub_block |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 49 | sub_block | one_page_sub_block |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 57 | sub_block | one_page_sub_block |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 96.4 | sub_block | one_page_sub_block |

## Do Not Rescue With Links

| title | board_score | reason |
| --- | ---: | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 85.4 | review_downrank |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 6.4 | review_downrank |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 58.6 | review_downrank |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 0 | market_risk, needs_news_hook, weak_audience_bridge |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 0 | review_downrank |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 47.6 | review_downrank |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 0 | sports_primary_downrank |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 49.4 | review_downrank |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 49 | review_downrank |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 57 | review_downrank |
| 에너지 가격 충격 / 전기요금 / 생활비 | 85.4 | review_downrank |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 6.4 | review_downrank |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 58.6 | review_downrank |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 0 | market_risk, needs_news_hook, weak_audience_bridge |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 0 | review_downrank |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 47.6 | review_downrank |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 0 | sports_primary_downrank |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 49.4 | review_downrank |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 49 | review_downrank |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 57 | review_downrank |

## Needs New Angle

| title | board_score | action |
| --- | ---: | --- |
| none | 0 | none |

## Board Score Distribution

- total_candidate_count: 55
- eligible_count: 28
- selected_count: 10
- selected_board_score_floor: 0

### Top Board Score Candidates

| title | total_score | board_score | reasons |
| --- | ---: | ---: | --- |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 71.4 | 96.4 | base_total_score=71.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +6 strong_angle_shift |
| 플랫폼 무료배달 / 수수료 비용 배분 | 64 | 89 | base_total_score=64; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +6 strong_angle_shift |
| 에너지 가격 충격 / 전기요금 / 생활비 | 71.4 | 85.4 | base_total_score=71.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +6 strong_so_what; +2 syuka_adjacent_context |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | 64 | 74 | base_total_score=64; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what |
| 공공/현장 AI 도입과 책임 | 65.4 | 61.4 | base_total_score=65.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; -18 weak_audience_bridge; +6 strong_angle_shift |
| ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | 50.6 | 60.6 | base_total_score=50.6; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 50.6 | 58.6 | base_total_score=50.6; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 65 | 57 | base_total_score=65; +6 strong_so_what; +2 syuka_adjacent_context; -18 evidence_only; +6 strong_angle_shift |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 71.4 | 49.4 | base_total_score=71.4; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 67 | 49 | base_total_score=67; +5 seed_with_supporting_links; +3 conditional_or_bundle_seed; +2 conditional_so_what; +2 syuka_adjacent_context |
