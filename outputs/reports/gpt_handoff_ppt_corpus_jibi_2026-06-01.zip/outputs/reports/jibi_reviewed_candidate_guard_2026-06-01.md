# Jibi Reviewed Candidate Guard — 2026-06-01

Report-only guard for suppressing candidates that already received human review.

- allow_reviewed_candidates: false
- selected_count: 10
- suppressed_count: 3

## New Candidates

| title | story_fingerprint | history_status |
| --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | energy_price_living_cost | new |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | story_33bfe1326f | new |
| 공공/현장 AI 도입과 책임 | public_ai_adoption | new |
| 플랫폼 무료배달 / 수수료 비용 배분 | platform_fee_allocation | new |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | story_e383c62b2f | new |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | story_e56aa46716 | new |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | story_240503a6d6 | new |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | story_62979e38b8 | new |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | story_e7e4b26675 | new |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | story_e18a7486fc | new |

## Suppressed Reviewed Candidates

| title | previous_review_dates | reviewers | status | required_action | excerpt |
| --- | --- | --- | --- | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 2026-05-25 | 형찬 | promoted_before | avoid_duplicate_review_unless_followup_news_changed | 자료는 조금 다르지만 청년 노동시장 주제, 특히 쉬었음 소재는 많이 다룬 바 있음. 최근 영상 제목으로는 "83~95년생의 삶을 추적해봤습니다.", "이제 근로소득으로는 부자가 될 수 없나" 정도가 있음. 즉, 좋... |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 2026-05-27 | 동찬 | reviewed_before | use_second_search_or_new_frame_before_reposting | 슈카월드는 경제학 교과서 채널이 아니야. |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 2026-05-25 | 형찬 | rejected_before | do_not_repost_without_new_hook_or_explicit_override | 이것도 재미가 없을 듯함. seed로 보기에는 약함. 조각투자를 교과서처럼 설명하면, "그래서 뭐" 반응이 나올 것임. |

## Reconsideration Rule

- Default: reviewed candidates are excluded from the next visible Jibi board.
- Override only with `JIBI_ALLOW_REVIEWED_CANDIDATES=1` after a new hook, new supporting links, or a clearly changed frame exists.
