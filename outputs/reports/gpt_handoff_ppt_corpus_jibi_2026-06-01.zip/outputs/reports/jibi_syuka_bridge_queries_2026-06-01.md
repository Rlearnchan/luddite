# Jibi Syuka Bridge Query Contract — 2026-06-01

Report-only query terms for later Windows Codex / syuka-ops past-video checks.
No syuka-ops DB was queried by luddite.

## Syuka Bridge Handoff Notes

- Send the JSON package to Windows Codex / syuka-ops for read-only past-video checks.
- Expected downstream labels: duplicate, adjacent, safe_new_angle, needs_human_check.
- Triggers from reviewer modifiers are high priority; luddite still does not inspect the DB.

## Query Records

| priority | trigger | title | core_terms | context_terms | expected_match_type | why_check_past_video | review_excerpt |
| --- | --- | --- | --- | --- | --- | --- | --- |
| high | heuristic | 에너지 가격 충격 / 전기요금 / 생활비 | 폭염, 열사병, 산업현장, 작업중지권, 노동안전 | 휴식, 냉방, 산재, 기업 책임 | title | review or heuristics suggest possible past-topic overlap |  |
| high | review_modifier:past_topic_overlap | 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 쉬었음, 비경제활동, 경제활동참가율, 청년 노동시장 | 근로소득, 청년 | title | review or heuristics suggest possible past-topic overlap | 자료는 조금 다르지만 청년 노동시장 주제, 특히 쉬었음 소재는 많이 다룬 바 있음. 최근 영상 제목으로는 "83~95년생의 삶을 추적해봤습니다.", "이제 근로소득으로는 부자가 될 수 없나" 정도가 있음. 즉, 좋... |
| high | heuristic | Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 폭염, 열사병, 산업현장, 작업중지권, 노동안전 | 휴식, 냉방, 산재, 기업 책임 | title | review or heuristics suggest possible past-topic overlap |  |
| high | board_reappearance | [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 자산 토큰화, RWA, STO, 조각투자 | CBDC, 디지털 화폐, 토큰증권 | analysis | compare with past videos before promoting repeated themes | 이것도 재미가 없을 듯함. seed로 보기에는 약함. 조각투자를 교과서처럼 설명하면, "그래서 뭐" 반응이 나올 것임. |
| low | heuristic | "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 석유보다, 비싼, 메모리칩 | 빅3, 시총이, 오일 | analysis | compare with past videos before promoting repeated themes |  |
| high | heuristic | Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 폭염, 열사병, 산업현장, 작업중지권, 노동안전 | 휴식, 냉방, 산재, 기업 책임 | title | review or heuristics suggest possible past-topic overlap |  |
| medium | heuristic | IBK기업은행, AI 불완전판매 탐지 시스템 도입 | IBK기업은행, AI, 불완전판매 | 탐지, 시스템, 도입 | analysis | compare with past videos before promoting repeated themes |  |
| low | heuristic | Put a £5 deposit on vapes to stop littering, say waste companies | Put, deposit, on | vapes, to, stop | analysis | compare with past videos before promoting repeated themes |  |
| medium | heuristic | Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | Samsung, memory, chip | staff, in, line | analysis | compare with past videos before promoting repeated themes |  |
| high | heuristic | [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 방위사업청, 레이저대공무기, 천광 | 핵심, 구성품, 레이저발진기 | analysis | compare with past videos before promoting repeated themes |  |
