# Jibi Syuka Snapshot Matches — 2026-06-01

Report-only local snapshot probe. No syuka-ops repo, Windows Docker, or syuka DB writes were performed.

## Snapshot Status

- status: usable
- reason: 
- db_path: `/Users/bae/Documents/code/syuka-ops/data/db/syuka_ops.db`
- syuka_data_dir: `/Users/bae/Documents/code/syuka-ops/data`
- document_count: 2269
- query_count: 10

## Query Summary

- adjacent: 8
- duplicate: 1
- needs_human_check: 1

## High-priority Past-overlap Checks

| query | recommendation | top_match | score | matched_terms |
| --- | --- | --- | ---: | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | adjacent | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | duplicate | '쉬었음' 역대 최고인데, 실업률은 왜 최저인가? | 12 | 근로소득, 비경제활동, 쉬었음, 청년 |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | adjacent | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | adjacent | 미래 화폐 주도권, 누가 가져갈 것인가 | 6 | cbdc, 디지털 화폐 |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan | adjacent | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | adjacent | [중소벤처기업부 x 슈카월드] 우리의 핵심기술을 지키는 방법 | 5 | 핵심 |

## Matches By Query

### 에너지 가격 충격 / 전기요금 / 생활비

- story_fingerprint: `energy_price_living_cost`
- priority: high
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: 폭염, 반바지, 여름 근무, 쿨비즈, 회사 복장, 열사병, 산업현장, 작업중지권, 노동안전, 휴식, 냉방, 산재, 기업 책임
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 8 | adjacent | title, analysis, transcript | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 2025-07-10 | 340736 | 3523 | 폭염 | 냉방 | ...망 과부화와 정전 위험을 초래할 수 있다는 점을 경고합니다. 오래된 주택과 높은 폭염 현상으로 인해 에어컨 사용을 자제해야 하는 상황이 발생할 수 있습니다. 특히, 에어컨을 함부로 사용하면 정전 위험이 더욱 커지므로 주의가 필요합니다. 유럽의 경험을 통해 한국 사회 역시 에어컨 사용량 증가에 따른 문제점을 인식하고, 전력... |
| 7 | adjacent | analysis, transcript | 아시아와 유럽에 닥친 역사상 최악의 더위 | 2025-07-09 | 838197 | 9399 | 폭염 | 냉방, 휴식 | ...조심을 하고 주의를 하고 가야 되고요 현재 기상청은 6월 말부터 이미 전국적으로 폭염과 열대야 사실상 경고를 날렸어요 더위로 인한 피해가 없도록 철저한 대비가 필요하다 6월입니다 6월입니다, 6월 그리고 지금 7월로 들어서니까 7월 낮 최고 기온이 이미 웬만한 전국은 30도가 넘었는데 강릉 36도 대구 36도 대구는 제가... |
| 3 | needs_human_check | analysis, transcript | 40년 만의 가장 추운 겨울이 왔다. | 2022-12-27 | 925512 | 12558 | 폭염 |  | ...인터뷰 했던 거 기억나죠? 주제로 잘 써먹었습니다 감사합니다 또 유럽은 기록적인 폭염이라면서요 막 40도, 50도 넘어간다- 역시 주제로 잘 써먹었습니다 화재가 뭐 유럽을 덮었네, 터키는 뭐 전체 땅의 몇 %가 타버렸네 어머! 이탈리아 날라가요- 잘 써먹었죠, 잘 써먹었는데 이게 올해였어요 올해 가뭄, 폭염 뭐 산불! 이... |
| 3 | needs_human_check | analysis, transcript | 996 근무, 과로에 신음하는 중국 | 2025-05-20 | 1176744 | 10532 |  | 휴식 | ...과도한 과로 문화, 경쟁 문화 문제가 있다 그리고 중국 국무원은 3월에 근로자의 휴식과 휴가에 대한 권리가 원래 있지만 다시 한 번 명시했어요 휴식과 휴가를 하고 유급휴가를 장려하자 그렇기 때문에 아까 말씀드린 중국 대기업들이 DJI도 그렇고 마이디어도 그렇고 오후 9시 퇴근에 의무화하자 이거 웃기네요 오후 9시 퇴근은... |
| 3 | needs_human_check | analysis, transcript | 9월 날씨가 이게 맞나? | 2024-09-16 | 729339 | 10901 | 폭염 |  | ...좀 더워도 너무 더운 거 아닌가? 그냥 조금 더운 게 아니라 뭔가 이상해 뭔가 폭염은 언제나 있었지 폭염은 언제나 있고 호들갑 떠는 게 아니라 9월 중순인데 아 이게 뭔가 이상해요 뭔가 저만 느끼는 게 아닌 것 같은 게 9월 14일 지금 현재 전국이 놀랍게도 폭염경보입니다 폭염경보야 주의보도 아니야 경보야 게다가 나라... |

### 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율

- story_fingerprint: `youth_labor_exit`
- priority: high
- trigger: review_modifier:past_topic_overlap
- recommendation: duplicate
- past_video_response_signal: popular_topic_update_candidate
- effective_query_terms: 쉬었음, 경제활동참가율, 비경제활동, 청년 노동시장, 근로소득, 청년
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 12 | duplicate | title, analysis, transcript | '쉬었음' 역대 최고인데, 실업률은 왜 최저인가? | 2025-04-04 | 1393740 | 12627 | 비경제활동, 쉬었음 | 근로소득, 청년 | ## 스크립트 요약 (5~10줄) 본 스크립트는 최근 한국 청년층의 고용 현황과 문제점을 분석하고, 고용률 상승과 실업률 하락이라는 ‘기적’을 설명합니다. 장기간 노동 시장에 진입하지 않고 쉬는 청년들이 증가하면서 비경제활동 인구가 늘어나고, 이로 인해 실업률이 감소하는 현상이 나타납니다. 하지만 이러한 상황은 결국 취업... |
| 10 | adjacent | title, analysis, transcript | 이제 근로소득으로는 부자가 될 수 없나 | 2026-02-16 | 1005066 | 10223 |  | 근로소득, 청년 | ...택(서울 아파트) 자산이 계층 이동에 결정적 역할을 한다고 분석한다. 결과적으로 근로소득만으로 자산을 축적해 부자가 되기 어려워진 현실과 그로 인한 청년층의 레버리지·고위험 행태 확대 우려를 제기하며, 계층 이동성을 회복할 정책적 난제를 강조한다. ["추적60분", "SNS 다단계", "청소년 유혹", "한국은행 BOK... |
| 7 | adjacent | title, analysis, transcript | 더 유리해진 청년도약계좌 갈아타기 | 2024-02-22 | 732254 | 9642 |  | 청년 | 스크립트 요약 (5~10줄) 이 스크립트는 청년 시드머니 마련을 위한 ‘청년도약계좌’를 소개하고 있습니다. 이 계좌는 정부 기여금을 포함해 연 7.68~9.47%의 높은 금리 혜택을 제공하며, 3년 이상 보유 시 비과세 혜택도 유지됩니다. 3년 미만 중도 해지 시에도 특별 중도 해지 요건(사망, 해외 이주, 퇴직 등) 충... |
| 7 | adjacent | title, analysis, transcript | 면접 수당을 드립니다! 2022 경기도 청년면접수당 제도 [유료광고포함] | 2022-08-25 | 142215 | 2279 |  | 청년 | 경기도 청년 면접 수당 제도가 2022년에 재개되었습니다. 면접비를 최대 30만원까지 지원하며, 1회 면접 시 5만원을 지급합니다. 대상은 경기도 소재 청년 면접 응시자(만 39세 이하)로, 주민등록상 경기도 거주자 및 가족이 대표인 사업장 제외해야 합니다. 신청 기간은 8월 22일부터 9월 23일까지이며, thankyo... |
| 7 | adjacent | analysis, transcript | 신입 채용 역대 최소 기록, 사라지는 일자리 | 2025-11-26 | 568898 | 5145 | 비경제활동, 쉬었음 | 청년 | ...본격적으로 중후장대형 제조업에서도 이 여파가 나오고 있고 그리고 이렇다 보니까 청년들이 떠나죠 일할 사람이 없어요 심각한 인력 부족에 시달리고 악순환을 계속 이루고 있고 게다가 요즘에 특히 자유무역이 쇠퇴합니다 블록형, 블록형이 되고 있어요 물론 그 블록 안에 우리가 잘 들어가면 위기를 기회로 삼을 수 있을 것 같은데... |

### Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous

- story_fingerprint: `story_33bfe1326f`
- priority: high
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: 폭염, 반바지, 여름 근무, 쿨비즈, 회사 복장, 열사병, 산업현장, 작업중지권, 노동안전, 휴식, 냉방, 산재, 기업 책임
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 8 | adjacent | title, analysis, transcript | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 2025-07-10 | 340736 | 3523 | 폭염 | 냉방 | ...망 과부화와 정전 위험을 초래할 수 있다는 점을 경고합니다. 오래된 주택과 높은 폭염 현상으로 인해 에어컨 사용을 자제해야 하는 상황이 발생할 수 있습니다. 특히, 에어컨을 함부로 사용하면 정전 위험이 더욱 커지므로 주의가 필요합니다. 유럽의 경험을 통해 한국 사회 역시 에어컨 사용량 증가에 따른 문제점을 인식하고, 전력... |
| 7 | adjacent | analysis, transcript | 아시아와 유럽에 닥친 역사상 최악의 더위 | 2025-07-09 | 838197 | 9399 | 폭염 | 냉방, 휴식 | ...조심을 하고 주의를 하고 가야 되고요 현재 기상청은 6월 말부터 이미 전국적으로 폭염과 열대야 사실상 경고를 날렸어요 더위로 인한 피해가 없도록 철저한 대비가 필요하다 6월입니다 6월입니다, 6월 그리고 지금 7월로 들어서니까 7월 낮 최고 기온이 이미 웬만한 전국은 30도가 넘었는데 강릉 36도 대구 36도 대구는 제가... |
| 3 | needs_human_check | analysis, transcript | 40년 만의 가장 추운 겨울이 왔다. | 2022-12-27 | 925512 | 12558 | 폭염 |  | ...인터뷰 했던 거 기억나죠? 주제로 잘 써먹었습니다 감사합니다 또 유럽은 기록적인 폭염이라면서요 막 40도, 50도 넘어간다- 역시 주제로 잘 써먹었습니다 화재가 뭐 유럽을 덮었네, 터키는 뭐 전체 땅의 몇 %가 타버렸네 어머! 이탈리아 날라가요- 잘 써먹었죠, 잘 써먹었는데 이게 올해였어요 올해 가뭄, 폭염 뭐 산불! 이... |
| 3 | needs_human_check | analysis, transcript | 996 근무, 과로에 신음하는 중국 | 2025-05-20 | 1176744 | 10532 |  | 휴식 | ...과도한 과로 문화, 경쟁 문화 문제가 있다 그리고 중국 국무원은 3월에 근로자의 휴식과 휴가에 대한 권리가 원래 있지만 다시 한 번 명시했어요 휴식과 휴가를 하고 유급휴가를 장려하자 그렇기 때문에 아까 말씀드린 중국 대기업들이 DJI도 그렇고 마이디어도 그렇고 오후 9시 퇴근에 의무화하자 이거 웃기네요 오후 9시 퇴근은... |
| 3 | needs_human_check | analysis, transcript | 9월 날씨가 이게 맞나? | 2024-09-16 | 729339 | 10901 | 폭염 |  | ...좀 더워도 너무 더운 거 아닌가? 그냥 조금 더운 게 아니라 뭔가 이상해 뭔가 폭염은 언제나 있었지 폭염은 언제나 있고 호들갑 떠는 게 아니라 9월 중순인데 아 이게 뭔가 이상해요 뭔가 저만 느끼는 게 아닌 것 같은 게 9월 14일 지금 현재 전국이 놀랍게도 폭염경보입니다 폭염경보야 주의보도 아니야 경보야 게다가 나라... |

### [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제

- story_fingerprint: `story_45dabd9919`
- priority: high
- trigger: board_reappearance
- recommendation: adjacent
- past_video_response_signal: popular_topic_update_candidate
- effective_query_terms: 자산 토큰화, cbdc, rwa, sto, 조각투자, 디지털 화폐, 토큰증권
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 6 | adjacent | analysis, transcript | 미래 화폐 주도권, 누가 가져갈 것인가 | 2022-05-11 | 1373268 | 21141 | cbdc | 디지털 화폐 | ...뭐 당연한 거 아니야 근데 이런 걸 왜 발표하냐 주요 내용은 이거였어요 중앙은행 디지털 화폐 CBDC 라고 그러죠 Central Bank Digital Currency, CBDC에 대한 개발과 연구를 백악관이 명령을 했어요 물론 국익에 부합한다고 판단될 경우에 자 그러면 왜 명령을 했고 특히 긴급하게 대응한다 라는 말이... |
| 6 | adjacent | analysis, transcript | 한국인들은 왜 레버리지만 하는가 | 2025-04-15 | 949833 | 10267 | cbdc | 디지털 화폐 | ...보니까 어? 잠깐만 자기 나라 국민들이 이렇게 암호화폐를 많이 해? 혹시... 디지털 화폐에 대한 수요가 늘어서 그런가? 그럼 우리도 디지털 화폐 CBDC 만들어서 우리가 대신 제공해줄까? 이런 생각을 합니다 CBDC는 뭐냐? 중앙은행이 발행하는 디지털 화폐예요 암호화폐는 디지털 화폐인데 커런시 암호를 걸어서 탈중앙화한... |
| 2 | needs_human_check | transcript | 비트코인은 미국의 전략적 비축자산이 되는가 | 2024-11-25 | 765403 | 9254 | cbdc | 디지털 화폐 | ...2024년 6월 28일 트럼프가 SNS에 이렇게 썼어요 비트코인 채굴은 우리가 CBDC에 저항하는 최후의 방어선이다 CBDC가 뭐냐면 중앙은행이 발행하는 디지털 화폐입니다 한마디로 중앙은행이 마치 비트코인처럼 디지털 화폐를 발행할 계획이 있다고 많은 여러 나라 중앙은행들이 저거를 실험하고 있는데 비트코인은 우리가 중앙은... |
| 1 | needs_human_check | transcript | 4차 산업 혁명과 빨라지는 디지털 전환, 승부를 거는 기업들 | 2021-01-27 | 333990 | 6627 |  | 디지털 화폐 | ...얼마전까지 찍는게 이상 했는데 이제는 자연스럽게 찍고 카페 같은 경우도 서서히 디지털 화폐 로 지금 바꾸겠다 뉴스 a 기뻤어요 디지털 자산 시장 이대역 똘 한다 여기다 무슨 자산을 넣는 우리가 스마트폰에 들어가는 게 오기도 지털 자사 디터 올레 시라는 것을 개발하고 저기도 원래 저개발 한데 저는 자산이 아니라 그냥 디지... |
| 1 | needs_human_check | transcript | 국가가 발행하는 '디지털 현금'의 시대와 치고 나오는 중국 | 2021-01-05 | 298490 | 5333 |  | 디지털 화폐 | 으 out 중국이 국가차원의 디지털 화폐 를 도입합니다 도입을 림이 신호를 했죠 시범사업을 해서 저장 성 하고 뭐 두 군데에서 디지털 앞에 도입을 한다고 디지털 위안화 를 만들겠다고 이미 선언을 하고 시범적으로 사용하고 있어 이렇게 생겼답니다 스마트폰의 저렇게 들어 있는 거죠 디지털 유화 디지털 화폐 비트코인 하고 똑같은... |

### "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다

- story_fingerprint: `story_36f50e67af`
- priority: low
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: 석유보다, 비싼, 메모리칩, 빅3, 시총이, 오일
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 6 | adjacent | title, analysis | [슈카월드 32화] (3) 우리의 미래 치킨집의 현재? 오일 쇼크와 셰일혁명 | 2018-05-10 | 1844 | 44 |  | 오일 | 슈카월드 32화에서는 오일 쇼크와 셰일혁명에 대한 이야기를 나누며, 합동 방송 진행에 대한 논의가 이루어집니다. 브러쉬 방송의 전문성을 강조하며, 수요 방송과 차별성을 두고 있습니다. 방송 주제를 시청자들에게 요청하고, 질문이나 제안을 받아 답변하고 소통하는 방식을 설명합니다. 방송 진행에 대한 의지를 밝히며, 시청자들에... |
| 5 | adjacent | title, transcript | [슈카월드 32화] (2) 우리의 미래 치킨집의 현재? 오일 쇼크와 셰일혁명 | 2018-05-10 | 11277 | 215 |  | 오일 | [슈카월드 32화] (2) 우리의 미래 치킨집의 현재? 오일 쇼크와 셰일혁명 |
| 5 | adjacent | title, transcript | 너무 비싼 것 아니냐, 한계에 부딪힌 소비자 인내심 | 2024-08-08 | 975564 | 10830 | 비싼 |  | 너무 비싼 것 아니냐, 한계에 부딪힌 소비자 인내심 |
| 5 | adjacent | title, transcript | 마이크로소프트(MS). 세계에서 가장 비싼 기업이 된 비결 | 2019-04-27 | 531243 | 6773 | 비싼 |  | 마이크로소프트(MS). 세계에서 가장 비싼 기업이 된 비결 |
| 5 | adjacent | title, transcript | 먹고 살기 비싼 나라 대한민국 | 2023-01-25 | 963870 | 12585 | 비싼 |  | 먹고 살기 비싼 나라 대한민국 |

### Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan

- story_fingerprint: `story_e383c62b2f`
- priority: high
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: 폭염, 반바지, 여름 근무, 쿨비즈, 회사 복장, 열사병, 산업현장, 작업중지권, 노동안전, 휴식, 냉방, 산재, 기업 책임
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 8 | adjacent | title, analysis, transcript | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 2025-07-10 | 340736 | 3523 | 폭염 | 냉방 | ...망 과부화와 정전 위험을 초래할 수 있다는 점을 경고합니다. 오래된 주택과 높은 폭염 현상으로 인해 에어컨 사용을 자제해야 하는 상황이 발생할 수 있습니다. 특히, 에어컨을 함부로 사용하면 정전 위험이 더욱 커지므로 주의가 필요합니다. 유럽의 경험을 통해 한국 사회 역시 에어컨 사용량 증가에 따른 문제점을 인식하고, 전력... |
| 7 | adjacent | analysis, transcript | 아시아와 유럽에 닥친 역사상 최악의 더위 | 2025-07-09 | 838197 | 9399 | 폭염 | 냉방, 휴식 | ...조심을 하고 주의를 하고 가야 되고요 현재 기상청은 6월 말부터 이미 전국적으로 폭염과 열대야 사실상 경고를 날렸어요 더위로 인한 피해가 없도록 철저한 대비가 필요하다 6월입니다 6월입니다, 6월 그리고 지금 7월로 들어서니까 7월 낮 최고 기온이 이미 웬만한 전국은 30도가 넘었는데 강릉 36도 대구 36도 대구는 제가... |
| 3 | needs_human_check | analysis, transcript | 40년 만의 가장 추운 겨울이 왔다. | 2022-12-27 | 925512 | 12558 | 폭염 |  | ...인터뷰 했던 거 기억나죠? 주제로 잘 써먹었습니다 감사합니다 또 유럽은 기록적인 폭염이라면서요 막 40도, 50도 넘어간다- 역시 주제로 잘 써먹었습니다 화재가 뭐 유럽을 덮었네, 터키는 뭐 전체 땅의 몇 %가 타버렸네 어머! 이탈리아 날라가요- 잘 써먹었죠, 잘 써먹었는데 이게 올해였어요 올해 가뭄, 폭염 뭐 산불! 이... |
| 3 | needs_human_check | analysis, transcript | 996 근무, 과로에 신음하는 중국 | 2025-05-20 | 1176744 | 10532 |  | 휴식 | ...과도한 과로 문화, 경쟁 문화 문제가 있다 그리고 중국 국무원은 3월에 근로자의 휴식과 휴가에 대한 권리가 원래 있지만 다시 한 번 명시했어요 휴식과 휴가를 하고 유급휴가를 장려하자 그렇기 때문에 아까 말씀드린 중국 대기업들이 DJI도 그렇고 마이디어도 그렇고 오후 9시 퇴근에 의무화하자 이거 웃기네요 오후 9시 퇴근은... |
| 3 | needs_human_check | analysis, transcript | 9월 날씨가 이게 맞나? | 2024-09-16 | 729339 | 10901 | 폭염 |  | ...좀 더워도 너무 더운 거 아닌가? 그냥 조금 더운 게 아니라 뭔가 이상해 뭔가 폭염은 언제나 있었지 폭염은 언제나 있고 호들갑 떠는 게 아니라 9월 중순인데 아 이게 뭔가 이상해요 뭔가 저만 느끼는 게 아닌 것 같은 게 9월 14일 지금 현재 전국이 놀랍게도 폭염경보입니다 폭염경보야 주의보도 아니야 경보야 게다가 나라... |

### IBK기업은행, AI 불완전판매 탐지 시스템 도입

- story_fingerprint: `story_240503a6d6`
- priority: medium
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: ibk기업은행, 불완전판매, 탐지, 시스템, 도입
- filtered_query_terms: ai

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 9 | adjacent | title, analysis, transcript | SSG닷컴, 물류로 승부하다. 자동물류시스템 NE.O 센터 [유료광고포함] | 2021-08-12 | 308542 | 5222 |  | 도입, 시스템 | ...신세계백화점의 디지털 전환 전략, 특히 ‘네오 센터’와 ‘컴도’를 활용한 자동화 시스템 구축을 중심으로 논의하고 있습니다. 물류 센터 확장과 함께 자동화 설비를 도입하여 효율성을 높이고, 상장 가능성을 타진하며 투자를 확대하는 방안을 모색합니다. 3년 뒤 새벽에 네오 센터가 승부수를 두고, 주식 시장에서 승승장구하는 모습... |
| 8 | adjacent | title, analysis, transcript | ABS 도입 후 대박 난 한국 프로야구 | 2026-04-10 | 349365 | 3988 |  | 도입, 시스템 | KBO 리그는 자동 볼판정(ABS)과 피치클락 도입 이후 경기 속도가 빨라지면서 개막 후 폭발적인 인기를 얻어 2025년 관중 1,231만 명을 기록했고 4년 연속 개막전 전구장 매진, 3년 연속 천만 관중 행진을 이어가고 있다고 전했습니다. KBO 측은 피치클락으로 투·타 템포가 빨라져 속도감 있는 경기가 가능해졌고 A... |
| 8 | adjacent | title, analysis, transcript | 모든 게시물 자동번역을 도입한 X | 2026-04-22 | 373230 | 4360 |  | 도입, 시스템 | ...X(구 트위터)가 모든 게시물을 사용자 설정 언어로 자동 번역해 보여주는 기능을 도입했다고 전하며, AI 기반으로 작동해 번역된 문장이 기본으로 보이고 원문 보기 버튼을 통해 원문을 확인할 수 있다고 설명했다. 이 기능으로 전 세계 사람들이 각자 자신의 언어로 게시물을 읽고 소통할 수 있게 되어 진정한 지구촌 커뮤니케이션... |
| 7 | adjacent | title, analysis, transcript | [MAIN] 중국의 전국민 감시시스템! 전국민 Lv업 가즈아ㅋㅋ 사회신용시스템 - 슈카월드 아재 라디오 | 2019-02-02 | 164099 | 2009 |  | 시스템 | 방송은 중국의 사회신용시스템과 전국민 감시 확산을 주요 주제로 다룬다. 실제 사례로 자동차 경적 단속과 소음 식별·카메라 촬영으로 경적 빈도가 급감한 점을 들며 기술 발전으로 규제가 가능해졌고 2020년까지 전국 확대 예정임을 언급한다. 알리바바·텐센트 등 민간 IT기업이 개인 정보 접근에 시범 허용되며 국가사업에 사실상... |
| 6 | adjacent | analysis, transcript | ※★ 안전한 거래소, 충전가능, 12시간 영업합니다.★※ | 2025-07-30 | 348825 | 4019 |  | 도입, 시스템 | ...라고 생각을 못했어요 그리고 옆 나라를 보니까 일본 같은 경우는 저 대체거래소가 도입돼서 안정화되는데 거의 10년이 걸렸습니다 복수거래소를 열었어 근데 안 돼 10년 이상 정체기를 겪었고 최근에서야 니케이 일본 주가가 올라가니까 그래도 3개 대체거래소의 합산 점유율이 고작 10%입니다 3개 합친 게 우리나라는 지금 대체거... |

### Put a £5 deposit on vapes to stop littering, say waste companies

- story_fingerprint: `story_17cf1483b6`
- priority: low
- trigger: heuristic
- recommendation: needs_human_check
- past_video_response_signal: needs_human_check
- effective_query_terms: put, deposit, vapes, stop
- filtered_query_terms: on, to

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 3 | needs_human_check | analysis, transcript | [6.27 Full] 증시 역사상 최대의 폭망. 1962년 그날.. - 슈카월드 아재토크쇼 | 2018-06-27 | 11727 | 177 |  | stop | ...죽이는 스타 pd 님께 뭐 얘기 해 보겠지만 보겠지만 뭐 맛있지는 잘 모르겠구요 stop 님은 참여하실 진짜 모르겠습니다 디로 여러분 좋은 시간 되시구요 자세하게 결정이 되면 은 재 팽 미티 이외에 여러분들의 탈 알려드리도록 하겠습니다 모두가 다 부자되는 그날까지 안녕 어차피 나도 몰라요 이렇게 봤어요 안뇽 조 시간 되세... |
| 1 | needs_human_check | transcript | '르완다 플랜', 영국의 불법이민자 강제 추방 계획 | 2023-11-24 | 809758 | 9920 |  | stop | ...이렇게 선언을 했죠 2023년 3월에 소형 보트 난민을 완전히 종식시키겠다 여기 Stop the boats라고 써있죠 보트로 들어오는 불법 난민들을 완전히 종식시키겠다 불법 이주민법을 도입하겠다고 선언을 합니다 여기서 얘기하는 불법 이주민법이라는 게 뭐냐면 이주민법, 이민자법 그럴 수 있죠 영국에 비정기적으로 도착하는 모... |
| 1 | needs_human_check | transcript | (쿠키)기생충 짜파구리 효과로 물 들어온 농심, 열심히 노를 젓다 | 2020-02-23 | 139848 | 2317 | put |  | ...1개 오도로 어어 뭔 노원 안 와 뭐 원 원 낸들 퍼 3 나머지 는 하우스 하프 put 풀세트 킬 께 믹스 빅스 개월 안개 어법 진짜 걸려 두지 몰랐지 다는 는 자로 서버 200 엽사 에는 낳아 때 접근할 저희 가족 보지 못했는데 배급한 cj e&amp;m 의 배급사 에는 그날 점심이 소등심 을 넣은 짜 바울이 가 나왔다... |
| 1 | needs_human_check | transcript | [1.1Full] 2019년 새해도 대박 가자~ - 슈카월드 아재토크 라디오 풀버전 | 2019-01-05 | 8001 | 138 |  | stop | ...데 약 제가 그분의 발 뒤꿈치 그때 알았어 이런 님 감사합니다 8 시간동안 하한 stop 님을 역시 그 분의 먼발치에서 그림자 라도 따라 갔어야 했다 그럼 저런 앞의 세 명의 걸어가면 그중에 한번 스섹 이라는데 잡을 차 자지 말고 제 첫번째 입니다 잡을 하지 말고 타이밍 맞춰서 해야 된다 아 쑥 그걸 따라 갔어야 했는데... |
| 1 | needs_human_check | transcript | [10.19Full] 중국 최고의 인터넷스타들은 무엇을 할까 / 미래사업 아이템 / 사립초썰 - 슈카월드 아재토크 라디오 | 2018-10-26 | 18842 | 232 | put |  | ...다 예술의 결론은 괜찮은 것 같다 그쵸 12:44 나머지 얘기들은 그 특히 pk put 코리아 위치에 대해서 얘기 들려 그랬는데 그 다음 시간에 다시 간의 드리도록 하겠습니다 좀 자자 10:00 뭐야 이럴때 45 분야 아직 중학교 얘기도 아닌데 예 지금부터 껴 보내니까 끝났어 해도 될까요 왜 초등학교 튜토리얼 그러니까 밤... |

### Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal

- story_fingerprint: `story_09033c216b`
- priority: medium
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: popular_topic_update_candidate
- effective_query_terms: samsung, memory, chip, staff, line
- filtered_query_terms: in

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 4 | adjacent | title | 정신나간 사우디 신도시 프로젝트 The Line | 2022-10-20 | 2920749 | 27586 |  | line | 정신나간 사우디 신도시 프로젝트 The Line |
| 2 | needs_human_check | analysis | 급등락 중인 삼성생명, 고민에 빠진 삼성전자의 지분구조 변화 | 2020-08-21 | 278638 | 3926 | samsung |  | ...스크립트의 핵심 내용을 간결하게 전달하며, 핵심적인 정보들을 정리했습니다. ["Samsung Electronics", "stock", "legal issues", "investment", "Korea", "leadership", "growth"] |
| 2 | needs_human_check | analysis | 반도체 업체 시가총액 1위에 오른 TSMC와 2위로 밀려난 삼성전자 | 2020-07-20 | 634731 | 9397 | samsung |  | ...대한 기대감과 함께, 정보 부족에 대한 고민을 담고 있습니다. ["TSMC", "Samsung", "Intel", "6G", "semiconductors", "digital transformation", "innovation", "technology", "future", "growth"] |
| 1 | needs_human_check | transcript | 180도 태세전환, 에르도안 폼 미쳤다 | 2023-07-19 | 2093527 | 14064 |  | line | ...가지! 첫째, 나토는 확장의 충동을 접고 자제해라 Don't cross the line! Never cross the line! 선을 넘지 마라! 선을 넘지 마! Cross the line 하지 마, 선 넘지 마 네가 선 넘는 녀석들도 아니고 넘으면 안 돼 절대 넘지 말고 아시아쪽에 이렇게 침 바르는 거 4개국 보내서... |
| 1 | needs_human_check | transcript | 거칠어지는 한ㆍ중 관계 | 2023-06-21 | 696212 | 8797 |  | line | ...돌아다니는데 중국 선박이- 여기 우리 땅입니다~ 그 뭐 구단선(nine dash line)인가 뭔가 모르십니까? 그 바다 이렇게 우리 거죠? 너희들은 여기로 다니세요~ 뭐 이런 거 하잖아요! 여기 우리 거고x2 여기 우리 거니까 너희들은 여기로만 다니세요 여기로만 여기로 들어오면 바로 어딜 우리 영해에! 라는 걸 하는데... |

### [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공

- story_fingerprint: `story_9b5e50b19d`
- priority: high
- trigger: heuristic
- recommendation: adjacent
- past_video_response_signal: adjacent
- effective_query_terms: 방위사업청, 레이저대공무기, 천광, 핵심, 구성품, 레이저발진기
- filtered_query_terms: 

| score | recommendation | fields | title | date | views | likes | core_terms | context_terms | snippet |
| ---: | --- | --- | --- | --- | ---: | ---: | --- | --- | --- |
| 5 | adjacent | title, transcript | [중소벤처기업부 x 슈카월드] 우리의 핵심기술을 지키는 방법 | 2020-04-30 | 156014 | 3704 |  | 핵심 | [중소벤처기업부 x 슈카월드] 우리의 핵심기술을 지키는 방법 |
| 4 | adjacent | title | 아마존을 1조달러 제국으로 이끈 전략의 핵심, 아마존 프라임 | 2020-04-01 | 336273 | 5372 |  | 핵심 | 아마존을 1조달러 제국으로 이끈 전략의 핵심, 아마존 프라임 |
| 3 | needs_human_check | analysis, transcript | "48시간이 지나면, 이란 발전소를 초토화 시킬 것" | 2026-03-23 | 648043 | 5994 |  | 핵심 | ...서 약간 좀 어두운 말도 하셨어요 자 다시 생각하는 게 좋을 거다 유럽 국가들이 핵심 항로를 열기 위한 미국의 노력에 동참하지 않는다면 나토의 미래에 매우 좋지 않은 일이 될 것이다 very bad for the future of NATO라고 얘기를 했는데 나토에서 탈퇴는 안 하겠지만 나토의 미래가 정말 어두워질 수도 있... |
| 3 | needs_human_check | analysis, transcript | "중간선거 패배시, 나는 탄핵 당할 것이다." | 2026-01-21 | 725548 | 6892 |  | 핵심 | ...의 독립성은 우리가 봉사하는 시민들의 이익을 위한 물가 안정과 금융 경제 안정의 핵심적인 토대다 중앙은행의 독립성을 지켜라 라고 선언을 했죠 아마 지금 쯤 파월 의장 아저씨는 감동의 눈물 속에서 감동의 도가니탕 속에서 계시지 않을까 생각이 되고 전 세계 중앙은행 총재들과 월가 대형은행 CEO들이 일제히 제롬 파월 지지를... |
| 3 | needs_human_check | analysis, transcript | '금리 인하'를 예고한, 잭슨홀 파월 연설 결과 | 2025-08-25 | 576599 | 5560 |  | 핵심 | ...명백하게 드러난 것 같습니다 관세 인상으로 일부 상품의 가격이 상승하기 시작했어 핵심 PCE 물가가 2.9% 상승했네요 이제 관세는 소비자 물가에 미치는 영향이 명백하게 드러났습니다 향후 몇 달 동안 이 관세는 소비자 물가에 누적적으로 영향을 미칠 것이고 물론 그 시기와 규모에 대해서는 아직 불확실성이 높습니다 한마디로... |

## No-match Queries

- none

## Suggested Human Follow-up

- Treat `duplicate` as likely past-topic overlap before promotion.
- Treat `adjacent` as useful context; check whether the new angle is fresh.
- Treat `needs_human_check` as weak or transcript-only similarity.
- Treat `safe_new_angle` as no obvious local snapshot match, not proof of novelty.
