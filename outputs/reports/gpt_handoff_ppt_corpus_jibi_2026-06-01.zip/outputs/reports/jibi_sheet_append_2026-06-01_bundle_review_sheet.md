# jibi Google Sheet Append Report

- Target spreadsheet id: `1piIsrWAHqSWBk0PwouTK1DWccX3W0Sfqf3YUptXT8QU`
- Target sheet name: `Jibi`
- Input preview csv: `/Users/bae/Documents/code/luddite/outputs/daily_digest/2026-06-01_bundle_review_sheet.csv`
- Sheet schema: `bundle_review`
- Rows read: 10
- Rows appended: 10
- Duplicates skipped: 0
- Dry run: True
- Replace existing sheet values: True
- Sheet replace planned: True
- Sheet replaced: False
- Styling applied: False
- Sheet created: False
- Review comments found: False
- Review comment cells: 0
- Review overwrite allowed: False
- Review snapshot path: ``
- Review history archive path: ``
- Header status: `missing`
- Header safe to update: True
- Header reason: `missing_empty_sheet`
- Header update planned: True
- Header updated: False
- Header created: True
- Errors: 0

## Duplicate keys skipped

- none

## Errors

- none
