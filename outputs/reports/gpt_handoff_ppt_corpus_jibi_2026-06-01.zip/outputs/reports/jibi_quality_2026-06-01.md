# Jibi Candidate Quality Report

## Summary

- candidates scored: 536
- top candidates: 10
- quality-gated candidates: 536
- single_company_frame count: 9
- political_sensitivity count: 37

## Operator Summary

- run_health: ok
- primary_bottleneck: no_clear_bottleneck
- rendered_top_candidates: 10
- top_eligible_candidates: 35
- raw_candidates: 536
- recommended_operator_action: ok_to_append_if_digest_looks_good
- do_not_change_thresholds_yet: true

## Source Mix Experiment Review

### Source Role Distribution

Raw candidates:
- public_wire: 350
- section_news: 106
- market_wire: 20
- research_note: 20
- policy_release: 20
- academic_explainer: 20

Top candidates:
- section_news: 3
- public_wire: 3
- research_note: 3
- academic_explainer: 1

### Exact Source Distribution

Raw candidates:
- 연합뉴스 경제: 120
- 연합뉴스 세계: 119
- 연합뉴스 산업: 81
- The Guardian Business: 38
- The Guardian Technology: 26
- The Guardian Environment: 22
- 연합인포맥스: 20
- 한국은행: 20
- 정책브리핑: 20
- BBC News: 20
- The Conversation: 20
- 한국경제: 20
- NPR: 10

Top candidates:
- 연합뉴스 경제: 3
- 한국은행: 3
- The Guardian Business: 2
- The Conversation: 1
- The Guardian Environment: 1

### Source Role Balance

- official/research raw: 40
- official/research top: 3
- public/section raw: 456
- public/section top: 6
- academic raw: 20
- academic top: 1
- market raw: 20
- market top: 0

### Source Role Cap Warnings

- none

### Recommended Human Review Focus

- BOK research-note candidates: [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석 (한국은행, macro_research_note); [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 (한국은행, policy_research_note); [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가 (한국은행, macro_research_note); [제2026-4호] 첨단 바이오헬스 산업 육성방안: 바이오 데이터 활용 기반 구축을 중심으로 (한국은행, macro_research_note); [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 (한국은행, macro_research_note)
- Policy Briefing seed/evidence candidates: [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 (정책브리핑, policy_release_seed); [고용노동부]청년과 세계를 잇는 최대 일자리박람회, 「2026 글로벌탤런트페어」 개최 (정책브리핑, policy_release_seed); [법무부]농어촌 외국인 숙련인력 고용 한도 50%로 확대… 외국인 노동자 '부당 이직' 시 이전 경력도 인정 (정책브리핑, policy_release_seed); [산림청]산림청, '6월의 임업인'에 충북 청주에서 조경수를 재배하는 이우희 임업인 선정 (정책브리핑, policy_release_seed); [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박 (정책브리핑, policy_release_seed)
- The Conversation academic explainers: Can you own a voice? Taylor Swift’s latest legal move raises big questions for AI and copyright (The Conversation, other); Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous (The Conversation, life_change); The story of Pope Leo’s ‘landmark’ text on AI technology – by a member of its launch panel (The Conversation, other); We analysed 14 million Reddit posts to reveal a striking shift in how we talk about mental health (The Conversation, other); Deep-sea sponges survive in complete darkness in ways we didn’t know before (The Conversation, other)
- Yonhap economy/industry/international seeds: 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 (연합뉴스 경제, platform_labor_market); "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 (연합뉴스 세계, other); 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 (연합뉴스 세계, other); 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 (연합뉴스 세계, other); 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 (연합뉴스 경제, public_ai_governance)

## Review Board Experiment Snapshot

- board_row_count: 10
- source_mix: 한국은행=2, The Guardian Business=1, The Conversation=1, 연합뉴스 세계=1, The Guardian Environment=1, 연합인포맥스=1, BBC News=1, The Guardian Technology=1, 정책브리핑=1
- story_reappearance_status: new=8, promoted_before=1, rejected_before=1
- sublink_count_distribution: 0_links=8, 1_links=2
- score_distribution: 70+=3, 50-69=6, 1-49=1
- source_mix_warning: none

## Source Role Cap Status

- cap_backfill_used: false
- research_note: selected=3 cap=3
- policy_release: selected=0 cap=2
- public_wire: selected=3 cap=3
- academic_explainer: selected=1 cap=2
- market_wire: selected=0 cap=1
- section_news: selected=3 cap=3
- cap_backfill_candidates: none

## Source Role Cap-blocked Candidates

| title | source | source_role_class | score | reason |
| --- | --- | --- | ---: | --- |
| 'AI 융합형 교육실' 전국 118개교에 구축…167억원 투입 | 연합뉴스 산업 | public_wire | 64 | source_role_cap_reached=public_wire:3 |
| 재생에너지 잠재량·병해충 진단…AI 공공데이터 25종 개방 | 연합뉴스 산업 | public_wire | 61 | source_role_cap_reached=public_wire:3 |
| 과기정통부 R&D 행정에 AI 접목…논문분석·법령해설 활용 | 연합뉴스 산업 | public_wire | 58 | source_role_cap_reached=public_wire:3 |
| 부산대, 지역사회 개방형 'AI 교육플랫폼' 구축한다 | 연합뉴스 산업 | public_wire | 58 | source_role_cap_reached=public_wire:3 |
| 中인민일보 "AI, 중미 협력 새 영역…디커플링, 권익 해쳐" | 연합뉴스 세계 | public_wire | 58 | source_role_cap_reached=public_wire:3 |
| [영상] 15억짜리 미사일 대신…美, 1천만원대 저가무기로 드론 격추 | 연합뉴스 세계 | public_wire | 49.2 | source_role_cap_reached=public_wire:3 |

## Story Bundle Review

| bundle | primary | supporting/evidence | bundle_type | suggested_action |
| --- | --- | --- | --- | --- |
| story_bundle_71383e8c94 — 에너지 가격 충격 / 전기요금 / 생활비 | The household battery revolution that could change energy bills … and the world | supporting: ‘Hidden datacentre tax’ costing Irish households millions, report says | merged_seed | review_primary_and_bundle_supporting |
| story_bundle_2bdd0b9bb3 — 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석 | supporting: [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가 | merged_seed | review_primary_and_bundle_supporting |
| story_bundle_b98823d211 — Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | none | standalone_seed | review_as_explainer_seed |
| story_bundle_02c86c6679 — [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | none | standalone_seed | review_as_core_seed |
| story_bundle_b1ac29abaa — "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | none | needs_external_sources | review_template_queue |
| story_bundle_a98fcc2448 — Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | none | needs_external_sources | manual_editorial_review |
| story_bundle_719b8cee1d — IBK기업은행, AI 불완전판매 탐지 시스템 도입 | IBK기업은행, AI 불완전판매 탐지 시스템 도입 | none | needs_external_sources | review_template_queue |
| story_bundle_469333477b — Put a £5 deposit on vapes to stop littering, say waste companies | Put a £5 deposit on vapes to stop littering, say waste companies | none | needs_external_sources | review_template_queue |
| story_bundle_68c7da90eb — Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | none | needs_external_sources | review_template_queue |
| story_bundle_82f1c56bbe — [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | none | needs_external_sources | collect_price_life_or_industry_data |
| story_bundle_93a62c6321 — ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | none | needs_external_sources | manual_editorial_review |
| story_bundle_8ff119d6ba — 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | none | needs_external_sources | review_template_queue |
| story_bundle_7b5d4e352b — 공공/현장 AI 도입과 책임 | 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 | none | needs_external_sources | split_or_bundle_after_human_review |
| story_bundle_ca38814db4 — 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | none | needs_external_sources | collect_second_source_and_numbers |
| story_bundle_66fe17944a — 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | none | needs_external_sources | review_template_queue |
| story_bundle_f12d1adae5 — 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | none | needs_external_sources | review_template_queue |
| story_bundle_23b976dcf8 — 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | none | needs_external_sources | review_template_queue |
| story_bundle_cfdda67ce8 — 플랫폼 무료배달 / 수수료 비용 배분 | 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구 | none | needs_external_sources | collect_second_source_and_numbers |

## Syuka Similarity Summary

- report_status: available
- adjacent: 8
- duplicate: 1
- needs_human_check: 1

### High-confidence Duplicate Rows

| query | top_match | score | terms | fields | response_signal |
| --- | --- | ---: | --- | --- | --- |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | '쉬었음' 역대 최고인데, 실업률은 왜 최저인가? | 12 | 근로소득, 비경제활동, 쉬었음, 청년 | title, analysis, transcript | popular_topic_update_candidate |

### Adjacent / Context Rows

| query | top_match | score | terms | fields | response_signal |
| --- | --- | ---: | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 | title, analysis, transcript | adjacent |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 | title, analysis, transcript | adjacent |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 미래 화폐 주도권, 누가 가져갈 것인가 | 6 | cbdc, 디지털 화폐 | analysis, transcript | popular_topic_update_candidate |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | [슈카월드 32화] (3) 우리의 미래 치킨집의 현재? 오일 쇼크와 셰일혁명 | 6 | 오일 | title, analysis | adjacent |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | 유럽이 40°C 폭염을 에어컨 없이 버텨야하는 이유 | 8 | 냉방, 폭염 | title, analysis, transcript | adjacent |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | SSG닷컴, 물류로 승부하다. 자동물류시스템 NE.O 센터 [유료광고포함] | 9 | 도입, 시스템 | title, analysis, transcript | adjacent |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 정신나간 사우디 신도시 프로젝트 The Line | 4 | line | title | popular_topic_update_candidate |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | [중소벤처기업부 x 슈카월드] 우리의 핵심기술을 지키는 방법 | 5 | 핵심 | title, transcript | adjacent |

### Needs Human Check Rows

| query | top_match | score | terms | fields | response_signal |
| --- | --- | ---: | --- | --- | --- |
| Put a £5 deposit on vapes to stop littering, say waste companies | [6.27 Full] 증시 역사상 최대의 폭망. 1962년 그날.. - 슈카월드 아재토크쇼 | 3 | stop | analysis, transcript | needs_human_check |

### Safe New Angle / No Local Match Rows

| query | top_match | score | terms | fields | response_signal |
| --- | --- | ---: | --- | --- | --- |
| none | none | 0 | none | none | none |

## Cross-run Duplicate / Reappearing Story Review

| story_fingerprint | title | status | note |
| --- | --- | --- | --- |
| youth_labor_exit | 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | promoted_before | 이전에 seed 의견이 있던 주제라 후속 업데이트인지 확인하세요. |
| story_45dabd9919 | [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | rejected_before | 이전에 reject 의견이 있던 주제라 다시 올릴 이유가 있는지 확인하세요. |
| public_ai_adoption | 공공/현장 AI 도입과 책임 | seen_before | 이전에 보드에 올라온 적이 있어 새 각도인지 확인하세요. |
| platform_fee_allocation | 플랫폼 무료배달 / 수수료 비용 배분 | seen_before | 이전에 보드에 올라온 적이 있어 새 각도인지 확인하세요. |

## Storyline Fit Audit

| role | title | source | seed_type | storyline_fit | merge_or_reason | suggested_operator_action |
| --- | --- | --- | --- | --- | --- | --- |
| top | The household battery revolution that could change energy bills … and the world | The Guardian Business | industry_disruption | needs_external_sources | story_fit_uncertain | manual_editorial_review |
| top | 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 연합뉴스 경제 | platform_labor_market | needs_external_sources | public_wire_story_has_concrete_broadcast_hook | collect_second_source_and_numbers |
| top | [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석 | 한국은행 | macro_research_note | merge_with_other_candidate | merge_target=[제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가 | bundle_before_sheet_review |
| top | [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 한국은행 | policy_research_note | standalone_seed | research_note_has_structural_numbers | review_as_core_seed |
| top | 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 | 연합뉴스 경제 | public_ai_governance | needs_external_sources | public_wire_story_has_concrete_broadcast_hook | collect_second_source_and_numbers |
| top | 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구 | 연합뉴스 경제 | platform_labor_market | needs_external_sources | public_wire_story_has_concrete_broadcast_hook | collect_second_source_and_numbers |
| top | [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가 | 한국은행 | macro_research_note | merge_with_other_candidate | merge_target=[제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석 | bundle_before_sheet_review |
| top | ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | The Guardian Business | life_change | needs_external_sources | story_fit_uncertain | manual_editorial_review |
| top | Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | The Conversation | life_change | standalone_seed | academic_explainer_has_mechanism | review_as_explainer_seed |
| top | Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't / Frances Ryan | The Guardian Environment | life_change | needs_external_sources | story_fit_uncertain | manual_editorial_review |
| near_miss | 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | industry_disruption | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 연합뉴스 세계 | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | ‘Hidden datacentre tax’ costing Irish households millions, report says | The Guardian Technology | policy_market_shock | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | The Guardian Technology | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 연합뉴스 세계 | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |
| near_miss | [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 정책브리핑 | policy_release_seed | needs_external_sources | official_release_seed_needs_independent_context | collect_price_life_or_industry_data |
| near_miss | Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | other | demote_or_reject | generic_why_without_specific_template | review_template_queue |

## So-What / Audience Interest Summary

- all_candidates: weak=405, strong=79, conditional=52
- top_candidates: strong=6, conditional=3, weak=1

## Weak Audience Bridge Examples

| title | source | score | classification | so_what | so_what_gap | audience_bridge_signals | quality_flags |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | 76 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, consequence_or_second_order_effect | weak_audience_bridge |
| 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | 71.4 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism | weak_audience_bridge |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 연합뉴스 세계 | 70.6 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | 67 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 연합뉴스 세계 | 67 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 | 연합뉴스 경제 | 65.4 | bundle_needed | weak | needs_concrete_audience_bridge_plus_mechanism | ai_entering_real_operations, korea_bridge | weak_audience_bridge |
| Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism | weak_audience_bridge |
| "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범 | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 한은 총재 "韓 성장 굉장히 강력…통화정책 조정 장애물 적어" | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| [천안소식] 갤러리아 센터시티 패션 브랜드 '위글위글' 오픈 | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |

## Interesting But Not Seed Queue

| title | source | score | classification | so_what | so_what_gap | audience_bridge_signals | quality_flags |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | 76 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, consequence_or_second_order_effect | weak_audience_bridge |
| 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | 71.4 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism | weak_audience_bridge |
| "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 연합뉴스 세계 | 70.6 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | 67 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 연합뉴스 세계 | 67 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism | weak_audience_bridge |
| "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범 | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 한은 총재 "韓 성장 굉장히 강력…통화정책 조정 장애물 적어" | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| [천안소식] 갤러리아 센터시티 패션 브랜드 '위글위글' 오픈 | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |
| 파리바게뜨, 필라델피아 국제공항 입점…미국 매장 300호점 넘어 | 연합뉴스 경제 | 64 | reject_or_downrank | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, korea_bridge | weak_audience_bridge |

## Conditional System-Issue Queue

| title | source | score | classification | so_what | so_what_gap | audience_bridge_signals | quality_flags |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | 71.4 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | direct_money_or_household_impact, distinctive_mechanism, consequence_or_second_order_effect | none |
| ‘Hidden datacentre tax’ costing Irish households millions, report says | The Guardian Technology | 67 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | The Guardian Technology | 67 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | BBC News | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | The Guardian Technology | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| Our tech overlords are planning for conscious AI to conquer the cosmos. What could go wrong? / Eduardo Porter | The Guardian Technology | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | The Guardian Technology | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | job_workplace_labor_change, distinctive_mechanism | none |
| Are robots nearing their ChatGPT moment? – podcast | The Guardian Technology | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| If you want to run your first marathon in your 50s, it helps to be chased by zombies | The Guardian Technology | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | distinctive_mechanism, global_story_bridge | none |
| 엔비디아, PC 출사표…젠슨 황 "AI 에이전트까지 구동하는 컴퓨터" | 연합인포맥스 | 64 | conditional_seed | conditional | conditional_seed_needs_second_source_or_story_bundle | direct_money_or_household_impact, distinctive_mechanism | none |

## Promo-Bulletin Suppression Queue

| title | source | score | guard_flags | so_what | action |
| --- | --- | ---: | --- | --- | --- |
| 쿠팡, 반려동물 용품 할인전 '펫페어' 진행…89개 브랜드 참여 | 연합뉴스 산업 | 48 | event_or_demonstration_only | weak | keep_for_later |
| The story of Pope Leo’s ‘landmark’ text on AI technology – by a member of its launch panel | The Conversation | 43 | product_or_certification_promo | weak | keep_for_later |
| 방미통위, AI 디지털윤리 공모전 개최 | 연합뉴스 산업 | 42 | contest_or_campaign_bulletin | weak | keep_for_later |
| 태광 실, 첫 브랜드 '사핀' 출시…"피부 회복력·재생력 강화" | 연합뉴스 산업 | 39.4 | product_or_certification_promo | weak | keep_for_later |
| 에이지투웨니스, 신제품 에센스 출시…'이븐 스킨 시스템' 적용 | 연합뉴스 산업 | 39.4 | product_or_certification_promo | weak | keep_for_later |
| [조달청]국민주권정부 1주년, 기술선도·균형·공정성장을 이끄는 공공조달 개혁 성과 | 정책브리핑 | 35 | product_or_certification_promo | strong | keep_for_later |
| W컨셉, 오클리·메타 협업 'AI 스마트 글래스' 한정 판매 | 연합뉴스 산업 | 35 | product_or_certification_promo | strong | keep_for_later |
| 돈나무 언니, 로빈후드 팔고 방산주 매수 | 연합인포맥스 | 35 | product_or_certification_promo | weak | editorial_review |
| [공정거래위원회]트립닷컴 트래블 싱가포르 프라이빗 리미티드 및 (주)트립닷컴코리아의 전자상거래법 위반행위 제재 | 정책브리핑 | 35 | narrow_market_track_record | strong | keep_for_later |
| 토스인컴, 국내 세무 플랫폼 업계 최초 ISMS-P 인증 획득 | 연합뉴스 경제 | 35 | product_or_certification_promo | strong | keep_for_later |

## Evidence-Only Candidate Queue

| title | source | score | classification | so_what | so_what_gap | audience_bridge_signals | quality_flags |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 정책브리핑 | 65 | evidence_only | strong | clear_audience_bridge_and_mechanism | direct_money_or_household_impact, distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | policy_release_seed_signals=odd_hook,material_number,visual_proof_object, policy_release_material_seed_signal |
| [고용노동부]청년과 세계를 잇는 최대 일자리박람회, 「2026 글로벌탤런트페어」 개최 | 정책브리핑 | 53 | evidence_only | strong | clear_audience_bridge_and_mechanism | job_workplace_labor_change, distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | policy_release_seed_signals=material_number,life_impact, policy_release_material_seed_signal |
| [법무부]농어촌 외국인 숙련인력 고용 한도 50%로 확대… 외국인 노동자 '부당 이직' 시 이전 경력도 인정 | 정책브리핑 | 48.6 | evidence_only | strong | clear_audience_bridge_and_mechanism | job_workplace_labor_change, distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | policy_release_seed_signals=material_number,life_impact, policy_release_material_seed_signal |
| [산림청]산림청, '6월의 임업인'에 충북 청주에서 조경수를 재배하는 이우희 임업인 선정 | 정책브리핑 | 48.6 | evidence_only | strong | clear_audience_bridge_and_mechanism | job_workplace_labor_change, distinctive_mechanism, consequence_or_second_order_effect, everyday_analogy_or_life_hook, korea_bridge | policy_release_seed_signals=material_number,industry_mechanism, policy_release_material_seed_signal |
| [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박 | 정책브리핑 | 48.4 | evidence_only | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | policy_release_seed_signals=regulatory_conflict,industry_mechanism, policy_release_date_only_number, weak_audience_bridge |
| [보건복지부]'범부처 총력 대응'으로 마약 근절 전방위 압박 | 정책브리핑 | 48.4 | evidence_only | weak | needs_concrete_audience_bridge_plus_mechanism | distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | policy_release_seed_signals=regulatory_conflict,industry_mechanism, policy_release_date_only_number, weak_audience_bridge |
| The story of Pope Leo’s ‘landmark’ text on AI technology – by a member of its launch panel | The Conversation | 43 | evidence_only | weak | promo_or_bulletin_needs_stronger_system_issue | distinctive_mechanism, global_story_bridge | product_or_certification_promo |
| 태광 실, 첫 브랜드 '사핀' 출시…"피부 회복력·재생력 강화" | 연합뉴스 산업 | 39.4 | evidence_only | weak | promo_or_bulletin_needs_stronger_system_issue | distinctive_mechanism, korea_bridge, weird_hook_needs_structural_expansion | product_or_certification_promo, single_company_case_needs_bundle, weak_audience_bridge |
| 에이지투웨니스, 신제품 에센스 출시…'이븐 스킨 시스템' 적용 | 연합뉴스 산업 | 39.4 | evidence_only | weak | promo_or_bulletin_needs_stronger_system_issue | distinctive_mechanism, korea_bridge | product_or_certification_promo, single_company_case_needs_bundle, weak_audience_bridge |
| [산림청]국립산림품종관리센터, 국민 소통 강화를 위한 규제혁신 현장지원센터 운영 | 정책브리핑 | 38 | evidence_only | strong | clear_audience_bridge_and_mechanism | ai_entering_real_operations, distinctive_mechanism, korea_bridge | policy_release_evidence_default, policy_release_seed_signals=material_number,regulatory_conflict, policy_release_announcement_only, policy_release_meeting_only, policy_release_procedural_number_only |

## Conditional Seed / Bundle-needed Queue

| title | source | score | classification | so_what | audience_bridge_signals | weakness_signals |
| --- | --- | ---: | --- | --- | --- | --- |
| The household battery revolution that could change energy bills … and the world | The Guardian Business | 71.4 | bundle_needed | strong | direct_money_or_household_impact, distinctive_mechanism, everyday_analogy_or_life_hook, global_story_bridge | none |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 연합뉴스 경제 | 71.4 | bundle_needed | strong | direct_money_or_household_impact, job_workplace_labor_change, distinctive_mechanism, consequence_or_second_order_effect, everyday_analogy_or_life_hook, korea_bridge | none |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | 71.4 | conditional_seed | conditional | direct_money_or_household_impact, distinctive_mechanism, consequence_or_second_order_effect | none |
| ‘Hidden datacentre tax’ costing Irish households millions, report says | The Guardian Technology | 67 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | The Guardian Technology | 67 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 | 연합뉴스 경제 | 65.4 | bundle_needed | weak | ai_entering_real_operations, korea_bridge | weak_audience_bridge |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 정책브리핑 | 65 | evidence_only | strong | direct_money_or_household_impact, distinctive_mechanism, consequence_or_second_order_effect, korea_bridge | none |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | BBC News | 64 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | The Guardian Technology | 64 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| Our tech overlords are planning for conscious AI to conquer the cosmos. What could go wrong? / Eduardo Porter | The Guardian Technology | 64 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | The Guardian Technology | 64 | conditional_seed | conditional | job_workplace_labor_change, distinctive_mechanism | none |
| Are robots nearing their ChatGPT moment? – podcast | The Guardian Technology | 64 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| If you want to run your first marathon in your 50s, it helps to be chased by zombies | The Guardian Technology | 64 | conditional_seed | conditional | distinctive_mechanism, global_story_bridge | none |
| 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구 | 연합뉴스 경제 | 64 | bundle_needed | strong | direct_money_or_household_impact, job_workplace_labor_change, ai_entering_real_operations, distinctive_mechanism, consequence_or_second_order_effect, everyday_analogy_or_life_hook, korea_bridge | none |
| 'AI 융합형 교육실' 전국 118개교에 구축…167억원 투입 | 연합뉴스 산업 | 64 | bundle_needed | strong | ai_entering_real_operations, distinctive_mechanism, korea_bridge | none |

## Candidate Funnel

- raw_candidates: 536
- recent_candidates: 508
- unknown_freshness_candidates: 0
- stale_candidates: 28
- quality_flagged_candidates: 438
- quality_gate_pass_candidates: 35
- duplicate_grouped_candidates: 12
- duplicate_primary_candidates: 6
- top_eligible_candidates: 35
- rendered_top_candidates: 10

## Calibration Warnings

- none

## Calibration Summary

- summary_labels: likely_source_quality_issue + likely_generic_why_gate_pressure + likely_gate_too_strict + likely_duplicate_collapse
- top_eligible_candidates: 35
- rendered_top_candidates: 10

## Top Gate Reason Distribution

### All Non-top Candidates

- generic_why_for_unspecific_seed_type: 455
- story_role_not_top_seed=demote_or_reject: 372
- final_grade=D: 365
- score_below_35: 365
- action_not_top=reject: 262
- story_role_not_top_seed=evidence_for_larger_story: 42
- excluded_quality_flags=accident_single_event: 19
- source_cap_reached=3: 16
- market_rate_without_macro_bridge: 14
- excluded_quality_flags=stale_item: 12
- excluded_quality_flags=policy_release_evidence_default: 11
- below_render_limit=10: 9
- excluded_quality_flags=event_or_demonstration_only: 8
- near_duplicate_role=duplicate: 6
- story_role_not_top_seed=background_reference: 6
- excluded_quality_flags=contest_or_campaign_bulletin: 5
- excluded_quality_flags=narrow_market_track_record: 2
- live_political_volatility: 2
- single_company_without_broader_bridge: 2
- excluded_quality_flags=sports_only: 2
- excluded_quality_flags=event_or_demonstration_only,policy_release_evidence_default: 1

### Top 20 Non-top Candidates By Score

- generic_why_for_unspecific_seed_type: 19
- story_role_not_top_seed=demote_or_reject: 10
- story_role_not_top_seed=evidence_for_larger_story: 1

## What-if Gate Simulation

| scenario | top_eligible_count | projected_top_count | added_candidate_examples |
| --- | ---: | ---: | --- |
| current | 35 | 10 | none |
| allow_high_specificity_generic_why | 37 | 10 | IBK기업은행, AI 불완전판매 탐지 시스템 도입 (연합인포맥스, 71.4); [BOK 컨퍼런스] IMF 국장 "통화정책, 물가뿐 아니라 금융취약성도 고려해야"(종합) (연합인포맥스, 64) |
| allow_stale_editorial_categories | 35 | 10 | none |
| lower_min_score_30 | 35 | 10 | none |

## Slideability Summary

- high: 331
- medium: 205

## Top Candidates Detail

- The household battery revolution that could change energy bills … and the world: seed_type=industry_disruption, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화: seed_type=platform_labor_market, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석: seed_type=macro_research_note, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제: seed_type=policy_research_note, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대: seed_type=public_ai_governance, risk_flags=[], quality_flags=['weak_audience_bridge'], slideability=medium / source_card
- 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구: seed_type=platform_labor_market, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가: seed_type=macro_research_note, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave: seed_type=life_change, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous: seed_type=life_change, risk_flags=[], quality_flags=[], slideability=high / diagram+chart+source_card
- Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't | Frances Ryan: seed_type=life_change, risk_flags=[], quality_flags=[], slideability=high / diagram+source_card

## Source Freshness Summary

- 연합뉴스 경제: raw=120, top=3, recent=120, stale=0, unknown=0, empty_summary=0
- 연합뉴스 세계: raw=119, top=0, recent=119, stale=0, unknown=0, empty_summary=0
- 연합뉴스 산업: raw=81, top=0, recent=81, stale=0, unknown=0, empty_summary=0
- The Guardian Business: raw=38, top=2, recent=38, stale=0, unknown=0, empty_summary=0
- The Guardian Technology: raw=26, top=0, recent=18, stale=8, unknown=0, empty_summary=0
- The Guardian Environment: raw=22, top=1, recent=18, stale=4, unknown=0, empty_summary=0
- 연합인포맥스: raw=20, top=0, recent=20, stale=0, unknown=0, empty_summary=0
- 한국은행: raw=20, top=3, recent=4, stale=16, unknown=0, empty_summary=0
- 정책브리핑: raw=20, top=0, recent=20, stale=0, unknown=0, empty_summary=0
- BBC News: raw=20, top=0, recent=20, stale=0, unknown=0, empty_summary=0
- The Conversation: raw=20, top=1, recent=20, stale=0, unknown=0, empty_summary=0
- 한국경제: raw=20, top=0, recent=20, stale=0, unknown=0, empty_summary=20
- NPR: raw=10, top=0, recent=10, stale=0, unknown=0, empty_summary=0

## Source Survival Table

| source | raw | recent | unknown | stale | quality_flagged | top_eligible | top | dominant_flags | warning |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| 연합뉴스 경제 | 120 | 120 | 0 | 0 | 98 | 9 | 3 | weak_audience_bridge=88, product_or_certification_promo=11, single_company_case_needs_bundle=9 | ok |
| 연합뉴스 세계 | 119 | 119 | 0 | 0 | 110 | 2 | 0 | weak_audience_bridge=108, accident_single_event=9, market_rate_stress=2 | ok |
| 연합뉴스 산업 | 81 | 81 | 0 | 0 | 66 | 6 | 0 | weak_audience_bridge=64, event_or_demonstration_only=5, product_or_certification_promo=5 | ok |
| The Guardian Business | 38 | 38 | 0 | 0 | 27 | 2 | 2 | weak_audience_bridge=25, contest_or_campaign_bulletin=2, market_rate_stress=1 | ok |
| The Guardian Technology | 26 | 18 | 0 | 8 | 12 | 0 | 0 | weak_audience_bridge=8, stale_item=8, product_or_certification_promo=7 | source_zero_survivors |
| The Guardian Environment | 22 | 18 | 0 | 4 | 15 | 1 | 1 | weak_audience_bridge=13, stale_item=4 | ok |
| 연합인포맥스 | 20 | 20 | 0 | 0 | 17 | 0 | 0 | weak_audience_bridge=15, single_stock_or_asset_frame=6, single_company_case_needs_bundle=2 | source_zero_survivors |
| 한국은행 | 20 | 4 | 0 | 16 | 7 | 13 | 3 | weak_audience_bridge=7, accident_single_event=1 | ok |
| 정책브리핑 | 20 | 20 | 0 | 0 | 20 | 0 | 0 | policy_release_evidence_default=12, policy_release_procedural_number_only=12, weak_audience_bridge=8 | source_zero_survivors |
| BBC News | 20 | 20 | 0 | 0 | 19 | 0 | 0 | weak_audience_bridge=19, sports_only=2, accident_single_event=1 | source_zero_survivors |
| The Conversation | 20 | 20 | 0 | 0 | 17 | 2 | 1 | weak_audience_bridge=16, product_or_certification_promo=2, accident_single_event=1 | ok |
| 한국경제 | 20 | 20 | 0 | 0 | 20 | 0 | 0 | empty_summary=20, empty_summary_domestic_business=20, weak_audience_bridge=17 | source_many_empty_summary, source_zero_survivors |
| NPR | 10 | 10 | 0 | 0 | 10 | 0 | 0 | weak_audience_bridge=10, live_politics_or_statement=2 | source_zero_survivors |

## Source Recommendations

| source | recommendation | reason |
| --- | --- | --- |
| 연합뉴스 경제 | keep | has rendered top candidates |
| 연합뉴스 세계 | review | has eligible candidates but dominant flag weak_audience_bridge |
| 연합뉴스 산업 | review | has eligible candidates but dominant flag weak_audience_bridge |
| The Guardian Business | keep | has rendered top candidates |
| The Guardian Technology | hold_daily_fetch | source_zero_survivors |
| The Guardian Environment | keep | has rendered top candidates |
| 연합인포맥스 | hold_daily_fetch | source_zero_survivors |
| 한국은행 | keep | has rendered top candidates |
| 정책브리핑 | hold_daily_fetch | source_zero_survivors |
| BBC News | hold_daily_fetch | source_zero_survivors |
| The Conversation | keep | has rendered top candidates |
| 한국경제 | manual_only | many empty summaries; needs manual curation |
| NPR | hold_daily_fetch | source_zero_survivors |

## Source Allowlist Review Queue

| source | recommendation | reason | dominant_flags | raw_count | top_eligible_count | top_count | suggested_manual_action |
| --- | --- | --- | --- | ---: | ---: | ---: | --- |
| 연합뉴스 경제 | keep | has rendered top candidates | weak_audience_bridge=88, product_or_certification_promo=11, single_company_case_needs_bundle=9 | 120 | 9 | 3 | keep_enabled |
| 연합뉴스 세계 | review | has eligible candidates but dominant flag weak_audience_bridge | weak_audience_bridge=108, accident_single_event=9, market_rate_stress=2 | 119 | 2 | 0 | consider_hold_daily_fetch |
| 연합뉴스 산업 | review | has eligible candidates but dominant flag weak_audience_bridge | weak_audience_bridge=64, event_or_demonstration_only=5, product_or_certification_promo=5 | 81 | 6 | 0 | consider_hold_daily_fetch |
| The Guardian Business | keep | has rendered top candidates | weak_audience_bridge=25, contest_or_campaign_bulletin=2, market_rate_stress=1 | 38 | 2 | 2 | keep_enabled |
| The Guardian Technology | hold_daily_fetch | source_zero_survivors | weak_audience_bridge=8, stale_item=8, product_or_certification_promo=7 | 26 | 0 | 0 | consider_hold_daily_fetch |
| The Guardian Environment | keep | has rendered top candidates | weak_audience_bridge=13, stale_item=4 | 22 | 1 | 1 | keep_enabled |
| 연합인포맥스 | hold_daily_fetch | source_zero_survivors | weak_audience_bridge=15, single_stock_or_asset_frame=6, single_company_case_needs_bundle=2 | 20 | 0 | 0 | consider_hold_daily_fetch |
| 한국은행 | keep | has rendered top candidates | weak_audience_bridge=7, accident_single_event=1 | 20 | 13 | 3 | keep_enabled |
| 정책브리핑 | hold_daily_fetch | source_zero_survivors | policy_release_evidence_default=12, policy_release_procedural_number_only=12, weak_audience_bridge=8 | 20 | 0 | 0 | consider_hold_daily_fetch |
| BBC News | hold_daily_fetch | source_zero_survivors | weak_audience_bridge=19, sports_only=2, accident_single_event=1 | 20 | 0 | 0 | consider_hold_daily_fetch |
| The Conversation | keep | has rendered top candidates | weak_audience_bridge=16, product_or_certification_promo=2, accident_single_event=1 | 20 | 2 | 1 | keep_enabled |
| 한국경제 | manual_only | many empty summaries; needs manual curation | empty_summary=20, empty_summary_domestic_business=20, weak_audience_bridge=17 | 20 | 0 | 0 | manual_curation_only |
| NPR | hold_daily_fetch | source_zero_survivors | weak_audience_bridge=10, live_politics_or_statement=2 | 10 | 0 | 0 | consider_hold_daily_fetch |

## Source Quality Flags

- 연합뉴스 경제: weak_audience_bridge=88, product_or_certification_promo=11, single_company_case_needs_bundle=9, market_rate_stress=8, event_or_demonstration_only=3, accident_single_event=2
- 연합뉴스 세계: weak_audience_bridge=108, accident_single_event=9, market_rate_stress=2, misclassified_cost_asymmetry=1
- 연합뉴스 산업: weak_audience_bridge=64, event_or_demonstration_only=5, product_or_certification_promo=5, single_company_case_needs_bundle=5, contest_or_campaign_bulletin=1, accident_single_event=1
- The Guardian Business: weak_audience_bridge=25, contest_or_campaign_bulletin=2, market_rate_stress=1, product_or_certification_promo=1
- The Guardian Technology: weak_audience_bridge=8, stale_item=8, product_or_certification_promo=7, market_rate_stress=1
- The Guardian Environment: weak_audience_bridge=13, stale_item=4
- 연합인포맥스: weak_audience_bridge=15, single_stock_or_asset_frame=6, single_company_case_needs_bundle=2, market_rate_stress=2, broader_macro_angle=2, accident_single_event=2, product_or_certification_promo=1, single_company_frame=1
- 한국은행: weak_audience_bridge=7, accident_single_event=1
- 정책브리핑: policy_release_evidence_default=12, policy_release_procedural_number_only=12, weak_audience_bridge=8, policy_release_announcement_only=7, policy_release_material_seed_signal=6, policy_release_date_only_number=6, policy_release_meeting_only=6, policy_release_seed_signals=material_number=4, policy_release_seed_signals=material_number,life_impact=2, policy_release_seed_signals=material_number,industry_mechanism=2, policy_release_seed_signals=regulatory_conflict,industry_mechanism=2, policy_release_seed_signals=material_number,regulatory_conflict=2, meeting_or_coordination_only=2, policy_release_seed_signals=odd_hook,material_number,visual_proof_object=1, product_or_certification_promo=1, single_company_case_needs_bundle=1, policy_release_seed_signals=material_number,life_impact,regulatory_conflict=1, narrow_market_track_record=1, policy_release_seed_signals=visual_proof_object=1, event_or_demonstration_only=1
- BBC News: weak_audience_bridge=19, sports_only=2, accident_single_event=1, contest_or_campaign_bulletin=1
- The Conversation: weak_audience_bridge=16, product_or_certification_promo=2, accident_single_event=1
- 한국경제: empty_summary=20, empty_summary_domestic_business=20, weak_audience_bridge=17, accident_single_event=2, single_stock_or_asset_frame=1, single_company_frame=1, narrow_market_track_record=1, single_company_case_needs_bundle=1, contest_or_campaign_bulletin=1
- NPR: weak_audience_bridge=10, live_politics_or_statement=2

## Source Skew Warnings

- none

## Near Duplicate Groups

- `nd_ba67fa0756` primary=`5월에도 질주한 반도체…한국 수출 42% 돌파 '역대 최고'(종합)` source=연합뉴스 경제 score=53.6 count=2
  - primary: 연합뉴스 경제 / 5월에도 질주한 반도체…한국 수출 42% 돌파 '역대 최고'(종합) score=53.6; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 연합뉴스 경제 / 5월에도 질주한 반도체…한국 수출 42% 돌파 '역대 최고' score=53.6; reason=same_source_title_overlap_0.90_shared_9; shared_tokens=9; overlap=0.9
- `nd_1b41d116c7` primary=`[법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박` source=정책브리핑 score=48.4 count=2
  - primary: 정책브리핑 / [법무부]'범부처 총력 대응'으로 마약 근절 전방위 압박 score=48.4; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 정책브리핑 / [보건복지부]'범부처 총력 대응'으로 마약 근절 전방위 압박 score=48.4; reason=same_source_title_overlap_0.80_shared_8; shared_tokens=8; overlap=0.8
- `nd_8693fd8c3f` primary=`이정후, MLB서 첫 5안타 폭발…33일 만에 타율 3할 복귀(종합)` source=연합뉴스 세계 score=34.4 count=2
  - primary: 연합뉴스 세계 / 이정후, MLB서 첫 5안타 폭발…33일 만에 타율 3할 복귀(종합) score=34.4; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 연합뉴스 세계 / 이정후, MLB서 첫 5안타 폭발…33일 만에 타율 3할 복귀 score=34.4; reason=same_source_title_overlap_0.90_shared_9; shared_tokens=9; overlap=0.9
- `nd_6b2f8fdfd6` primary=`막내린 샹그릴라대화…미중 대립 누그러졌지만 미-유럽은 이견(종합)` source=연합뉴스 세계 score=34.4 count=2
  - primary: 연합뉴스 세계 / 막내린 샹그릴라대화…미중 대립 누그러졌지만 미-유럽은 이견(종합) score=34.4; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 연합뉴스 세계 / 막내린 샹그릴라대화…미중 대립 누그러졌지만 미·유럽은 이견 score=23.4; reason=same_source_title_overlap_0.88_shared_7; shared_tokens=7; overlap=0.88
- `nd_6274a428e2` primary=`미군 "주말에 이란 레이더·드론체제 시설 공습…자위권 차원"` source=연합뉴스 세계 score=30.8 count=2
  - primary: 연합뉴스 세계 / 미군 "주말에 이란 레이더·드론체제 시설 공습…자위권 차원" score=30.8; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 연합뉴스 세계 / [속보] 미군 "주말에 이란 레이더·드론체제 시설 공습…자위권 차원" score=24.8; reason=same_source_title_overlap_1.00_shared_9; shared_tokens=9; overlap=1.0
- `nd_86e3db9b95` primary=`이스라엘군, 레바논 남부 지상전 확대…요충지 '보포르' 장악(종합)` source=연합뉴스 세계 score=23.4 count=2
  - primary: 연합뉴스 세계 / 이스라엘군, 레바논 남부 지상전 확대…요충지 '보포르' 장악(종합) score=23.4; reason=highest_scoring_title_overlap_primary; shared_tokens=0; overlap=0.0
  - duplicate: 연합뉴스 세계 / 이스라엘군, 레바논 남부 지상전 확대…요충지 '보포르' 장악 score=23.4; reason=same_source_title_overlap_0.89_shared_8; shared_tokens=8; overlap=0.89

## Top Candidates Source Distribution

- 연합뉴스 경제: 3
- 한국은행: 3
- The Guardian Business: 2
- The Conversation: 1
- The Guardian Environment: 1

## Top Candidates Seed Type Distribution

- life_change: 3
- platform_labor_market: 2
- macro_research_note: 2
- industry_disruption: 1
- policy_research_note: 1
- public_ai_governance: 1

## Action Distribution

- reject: 262
- keep_for_later: 121
- gather_more_evidence: 98
- editorial_review: 55

## Source Candidate Count

- 연합뉴스 경제: 120
- 연합뉴스 세계: 119
- 연합뉴스 산업: 81
- The Guardian Business: 38
- The Guardian Technology: 26
- The Guardian Environment: 22
- 연합인포맥스: 20
- 한국은행: 20
- 정책브리핑: 20
- BBC News: 20
- The Conversation: 20
- 한국경제: 20
- NPR: 10

## Source Count After Quality Gate

- 한국은행: 13
- 연합뉴스 경제: 9
- 연합뉴스 산업: 6
- The Guardian Business: 2
- 연합뉴스 세계: 2
- The Conversation: 2
- The Guardian Environment: 1

## Top 10 Raw Score Before Gate

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": 76.0 / gather_more_evidence / flags=['weak_audience_bridge']
- The household battery revolution that could change energy bills … and the world: 71.4 / gather_more_evidence / flags=[]
- 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화: 71.4 / gather_more_evidence / flags=[]
- IBK기업은행, AI 불완전판매 탐지 시스템 도입: 71.4 / gather_more_evidence / flags=[]
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: 71.4 / gather_more_evidence / flags=['weak_audience_bridge']
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: 70.6 / gather_more_evidence / flags=['weak_audience_bridge']
- [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석: 68.4 / gather_more_evidence / flags=[]
- ‘Hidden datacentre tax’ costing Irish households millions, report says: 67.0 / gather_more_evidence / flags=[]
- Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal: 67.0 / gather_more_evidence / flags=[]
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: 67.0 / gather_more_evidence / flags=['weak_audience_bridge']

## Top After Gate

- The household battery revolution that could change energy bills … and the world: 71.4 / gather_more_evidence
- 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화: 71.4 / gather_more_evidence
- [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석: 68.4 / gather_more_evidence
- [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제: 67.0 / gather_more_evidence
- 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대: 65.4 / gather_more_evidence
- 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구: 64.0 / gather_more_evidence
- [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가: 64.0 / gather_more_evidence
- ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave: 50.6 / gather_more_evidence
- Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous: 50.6 / gather_more_evidence
- Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't | Frances Ryan: 39.6 / gather_more_evidence

## Removed From Raw Top By Gate/Balance

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": flags=['weak_audience_bridge'], failure_modes=['thin_evidence']
- IBK기업은행, AI 불완전판매 탐지 시스템 도입: flags=[], failure_modes=['thin_evidence']
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: flags=['weak_audience_bridge'], failure_modes=['thin_evidence']
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: flags=['weak_audience_bridge'], failure_modes=['thin_evidence']
- ‘Hidden datacentre tax’ costing Irish households millions, report says: flags=[], failure_modes=['thin_evidence']
- Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal: flags=[], failure_modes=['thin_evidence']
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: flags=['weak_audience_bridge'], failure_modes=['thin_evidence']

## Generic Why Template Improvement Queue

| title | source | score | story_specificity | why_interesting | suggested_template_direction |
| --- | --- | ---: | --- | --- | --- |
| 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | 76 | high:has_named_actor, has_number, has_mechanism, has_korea_bridge, has_visual_hook | 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" 이슈를 단일 기사로 소비하지 않고 공급망, 인프라, 규제, 산업 전환 중 어느 축으로 확장 가능한지 확인할 필요가 있음 | number_tension_bridge |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | 71.4 | high:has_named_actor, has_number, has_mechanism, has_visual_hook | IBK기업은행, AI 불완전판매 탐지 시스템 도입에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | 71.4 | medium:has_number, has_tension, has_visual_hook | 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | 67 | medium:has_named_actor, has_number, has_mechanism | 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | The Guardian Technology | 64 | medium:has_named_actor, has_number, has_mechanism | Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | The Guardian Technology | 64 | medium:has_named_actor, has_number, has_mechanism | ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| 한은 총재 "韓 성장 굉장히 강력…통화정책 조정 장애물 적어" | 연합뉴스 경제 | 64 | high:has_named_actor, has_number, has_mechanism, has_korea_bridge | 한은 총재 "韓 성장 굉장히 강력…통화정책 조정 장애물 적어"에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| 젠슨 황, AI 노트북 시장 진출 선언…삼성·SK 메모리 탑재 유력(종합) | 연합뉴스 산업 | 64 | medium:has_named_actor, has_number, has_mechanism | 젠슨 황, AI 노트북 시장 진출 선언…삼성·SK 메모리 탑재 유력(종합)에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| [BOK 컨퍼런스] IMF 국장 "통화정책, 물가뿐 아니라 금융취약성도 고려해야"(종합) | 연합인포맥스 | 64 | high:has_named_actor, has_number, has_mechanism, has_korea_bridge | [BOK 컨퍼런스] IMF 국장 "통화정책, 물가뿐 아니라 금융취약성도 고려해야"(종합)에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음 | number_tension_bridge |
| 엔비디아, PC 출사표…젠슨 황 "AI 에이전트까지 구동하는 컴퓨터" | 연합인포맥스 | 64 | medium:has_named_actor, has_number, has_mechanism | 엔비디아, PC 출사표…젠슨 황 "AI 에이전트까지 구동하는 컴퓨터" 이슈를 단일 기사로 소비하지 않고 공급망, 인프라, 규제, 산업 전환 중 어느 축으로 확장 가능한지 확인할 필요가 있음 | number_tension_bridge |

## Near Miss Review Queue

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": source=연합인포맥스; total_score=76; action=gather_more_evidence; grade=A; freshness=recent/0.0h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- IBK기업은행, AI 불완전판매 탐지 시스템 도입: source=연합인포맥스; total_score=71.4; action=gather_more_evidence; grade=B; freshness=recent/0.0h; quality_flags=none; failure_modes=thin_evidence; near_duplicate=none (none); reason=generic_why_for_unspecific_seed_type
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: source=연합인포맥스; total_score=71.4; action=gather_more_evidence; grade=B; freshness=recent/0.0h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: source=연합뉴스 세계; total_score=70.6; action=gather_more_evidence; grade=B; freshness=recent/4.3h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- ‘Hidden datacentre tax’ costing Irish households millions, report says: source=The Guardian Technology; total_score=67; action=gather_more_evidence; grade=B; freshness=recent/88.9h; quality_flags=none; failure_modes=thin_evidence; near_duplicate=none (none); reason=generic_why_for_unspecific_seed_type
- Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal: source=The Guardian Technology; total_score=67; action=gather_more_evidence; grade=B; freshness=recent/114.1h; quality_flags=none; failure_modes=thin_evidence; near_duplicate=none (none); reason=generic_why_for_unspecific_seed_type
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: source=연합뉴스 세계; total_score=67; action=gather_more_evidence; grade=B; freshness=recent/3.0h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상: source=연합뉴스 세계; total_score=67; action=gather_more_evidence; grade=B; freshness=recent/3.7h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공: source=정책브리핑; total_score=65; action=gather_more_evidence; grade=B; freshness=recent/2.2h; quality_flags=policy_release_seed_signals=odd_hook,material_number,visual_proof_object, policy_release_material_seed_signal; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=evidence_for_larger_story
- Put a £5 deposit on vapes to stop littering, say waste companies: source=BBC News; total_score=64; action=gather_more_evidence; grade=B; freshness=recent/5.4h; quality_flags=weak_audience_bridge; failure_modes=thin_evidence; near_duplicate=none (none); reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type

## Empty Summary Count By Source

- 한국경제: 20

## Top Failure Modes

- thin_evidence: 536
- sensitive_high_low_gain: 57
- product_or_certification_promo: 28
- live_news_volatility: 22
- single_event_accident: 19
- single_company_case_needs_bundle: 18
- policy_release_evidence_default: 12
- stale_rss_item: 12
- single_stock_investment_frame: 10
- event_or_demonstration_only: 9

## Generic Why Examples

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" 이슈를 단일 기사로 소비하지 않고 공급망, 인프라, 규제, 산업 전환 중 어느 축으로 확장 가능한지 확인할 필요가 있음
- IBK기업은행, AI 불완전판매 탐지 시스템 도입: IBK기업은행, AI 불완전판매 탐지 시스템 도입에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- ‘Hidden datacentre tax’ costing Irish households millions, report says: ‘Hidden datacentre tax’ costing Irish households millions, report says에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal: Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상: 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- Put a £5 deposit on vapes to stop littering, say waste companies: Put a £5 deposit on vapes to stop littering, say waste companies에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음
- Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days: Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days에서 출발해 사건 자체보다 배경, 이해관계자, 한국 시청자에게 닿는 구조적 연결고리가 있는지 추가 확인할 필요가 있음

## Generic Why / Specificity Examples

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": score=76; specificity=0.83 (high); signals=has_named_actor, has_number, has_mechanism, has_korea_bridge, has_visual_hook; generic_why_detected=True; suggested_action=improve_template; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- IBK기업은행, AI 불완전판매 탐지 시스템 도입: score=71.4; specificity=0.67 (high); signals=has_named_actor, has_number, has_mechanism, has_visual_hook; generic_why_detected=True; suggested_action=improve_template; reason=generic_why_for_unspecific_seed_type
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: score=71.4; specificity=0.5 (medium); signals=has_number, has_tension, has_visual_hook; generic_why_detected=True; suggested_action=manual_review; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: score=70.6; specificity=0.33 (low); signals=has_named_actor, has_number; generic_why_detected=True; suggested_action=keep_gate; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- ‘Hidden datacentre tax’ costing Irish households millions, report says: score=67; specificity=0.33 (low); signals=has_named_actor, has_number; generic_why_detected=True; suggested_action=keep_gate; reason=generic_why_for_unspecific_seed_type
- Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal: score=67; specificity=0.33 (low); signals=has_named_actor, has_number; generic_why_detected=True; suggested_action=keep_gate; reason=generic_why_for_unspecific_seed_type
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: score=67; specificity=0.5 (medium); signals=has_named_actor, has_number, has_mechanism; generic_why_detected=True; suggested_action=manual_review; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상: score=67; specificity=0.17 (low); signals=has_number; generic_why_detected=True; suggested_action=keep_gate; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- Put a £5 deposit on vapes to stop littering, say waste companies: score=64; specificity=0.17 (low); signals=has_number; generic_why_detected=True; suggested_action=keep_gate; reason=story_role_not_top_seed=demote_or_reject, generic_why_for_unspecific_seed_type
- Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days: score=64; specificity=0.17 (low); signals=has_number; generic_why_detected=True; suggested_action=keep_gate; reason=generic_why_for_unspecific_seed_type

## Downranked Examples

- 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능": weak_audience_bridge -> gather_more_evidence / A
- 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원: weak_audience_bridge -> gather_more_evidence / B
- "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다: weak_audience_bridge -> gather_more_evidence / B
- 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자: weak_audience_bridge -> gather_more_evidence / B
- 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상: weak_audience_bridge -> gather_more_evidence / B
- 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대: weak_audience_bridge -> gather_more_evidence / B
- [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공: policy_release_seed_signals=odd_hook,material_number,visual_proof_object, policy_release_material_seed_signal -> gather_more_evidence / B
- Put a £5 deposit on vapes to stop littering, say waste companies: weak_audience_bridge -> gather_more_evidence / B
- "AI공격은 AI로 방어"…고성능 AI 대응 민간자문단 출범: weak_audience_bridge -> gather_more_evidence / B
- 한은 총재 "韓 성장 굉장히 강력…통화정책 조정 장애물 적어": weak_audience_bridge -> gather_more_evidence / B
