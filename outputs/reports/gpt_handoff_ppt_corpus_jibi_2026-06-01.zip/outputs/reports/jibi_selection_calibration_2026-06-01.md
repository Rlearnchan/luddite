# Jibi Selection Calibration — 2026-06-01

Report-only calibration summary. Visible Google Sheet columns are unchanged.

- selected_count: 10
- recommended_visible_board_size: 9
- main_seed_count: 0
- sub_block_count: 9
- hook_only_count: 0
- evidence_count: 1
- suppress_candidate_count: 3
- needs_second_source_count: 0
- support_missing_count: 2
- syuka_false_positive_risk_count: 9
- past_overlap_needs_new_angle_count: 9

## Reviewer Lesson Counts

- past_syuka_overlap_needs_new_angle: 9
- platform_hidden_cost_bonus: 2
- sports_primary_downrank: 1
- syuka_similarity_false_positive_risk: 9

## Top 10 Before Calibration

| title | before | after | delta | role before | role after | lessons | missing support |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 91.4 | 96.4 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |
| 에너지 가격 충격 / 전기요금 / 생활비 | 89.4 | 85.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| 플랫폼 무료배달 / 수수료 비용 배분 | 84 | 89 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | 74 | 74 | 0 | sub_block | sub_block | - | - |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 62.6 | 58.6 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| 공공/현장 AI 도입과 책임 | 61.4 | 61.4 | 0 | sub_block | sub_block | - | - |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 61 | 57 | -4 | evidence | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | 60.6 | 60.6 | 0 | sub_block | sub_block | - | - |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 55 | 0 | -55 | sub_block | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 53.4 | 49.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |

## Top 10 After Calibration

| title | before | after | delta | role before | role after | lessons | missing support |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 91.4 | 96.4 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |
| 플랫폼 무료배달 / 수수료 비용 배분 | 84 | 89 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |
| 에너지 가격 충격 / 전기요금 / 생활비 | 89.4 | 85.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| ‘Instagram truly is the new LinkedIn’: why gen Z is using social media to get hired | 74 | 74 | 0 | sub_block | sub_block | - | - |
| 공공/현장 AI 도입과 책임 | 61.4 | 61.4 | 0 | sub_block | sub_block | - | - |
| ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | 60.6 | 60.6 | 0 | sub_block | sub_block | - | - |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 62.6 | 58.6 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 61 | 57 | -4 | evidence | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 53.4 | 49.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | 49 | 49 | 0 | sub_block | sub_block | past_syuka_overlap_needs_new_angle | - |

## Dropped By Calibration

| title | before | after | delta | role before | role after | lessons | missing support |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 89.4 | 85.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 62.6 | 58.6 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 61 | 57 | -4 | evidence | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 55 | 0 | -55 | sub_block | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 53.4 | 49.4 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan | 51.6 | 47.6 | -4 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | - |
| 청년 노동시장 이탈 / 쉬었음 / 경제활동참가율 | 51.4 | 6.4 | -45 | sub_block | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 48 | 23 | -25 | sub_block | evidence | - | - |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 41 | 0 | -41 | sub_block | evidence | sports_primary_downrank | - |

## Promoted By Calibration

| title | before | after | delta | role before | role after | lessons | missing support |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 91.4 | 96.4 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |
| 플랫폼 무료배달 / 수수료 비용 배분 | 84 | 89 | 5 | sub_block | sub_block | platform_hidden_cost_bonus | - |

## Role Changed By Calibration

| title | before | after | delta | role before | role after | lessons | missing support |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| [제2025-37호] 생산 부문으로의 자금 흐름 전환과 성장 활력 | 48 | 23 | -25 | sub_block | evidence | - | - |
| [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 55 | 0 | -55 | sub_block | evidence | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 41 | 0 | -41 | sub_block | evidence | sports_primary_downrank | - |

## Selected Rows

| title | before | after | editorial_role | lessons | support_requirements | why_not_main_seed |
| --- | ---: | ---: | --- | --- | --- | --- |
| 에너지 가격 충격 / 전기요금 / 생활비 | 89.4 | 85.4 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | 62.6 | 58.6 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| 공공/현장 AI 도입과 책임 | 61.4 | 61.4 | sub_block | - | - | needs supporting links, tighter frame, or main-story host |
| 플랫폼 무료배달 / 수수료 비용 배분 | 84 | 89 | sub_block | platform_hidden_cost_bonus | policy_or_stat | needs supporting links, tighter frame, or main-story host |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan | 51.6 | 47.6 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | 41 | 41 | sub_block | - | - | needs supporting links, tighter frame, or main-story host |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | 44 | 44 | sub_block | - | - | needs supporting links, tighter frame, or main-story host |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | 41 | 0 | evidence | sports_primary_downrank | - | sports topic is weak as the primary story |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 53.4 | 49.4 | sub_block | past_syuka_overlap_needs_new_angle, syuka_similarity_false_positive_risk | past_video_new_angle | past Syuka overlap means main seed needs a new angle; past-video match appears broad and needs human duplicate check |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | 44 | 44 | sub_block | - | - | needs supporting links, tighter frame, or main-story host |
