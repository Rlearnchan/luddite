# Jibi -> Anny Handoff - 2026-06-01

- handoff_version: jibi_anny_seed_v0
- item_count: 10

| title | editorial_role | confidence | primary topic | board_score |
| --- | --- | --- | --- | ---: |
| 에너지 가격 충격 / 전기요금 / 생활비 | sub_block | medium | energy_climate | 85.4 |
| Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | sub_block | medium | energy_climate | 58.6 |
| 공공/현장 AI 도입과 책임 | sub_block | medium | policy_government | 61.4 |
| 플랫폼 무료배달 / 수수료 비용 배분 | sub_block | medium | consumer_life | 89 |
| Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan | sub_block | medium | energy_climate | 47.6 |
| Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ | sub_block | medium | ai_tech | 41 |
| IBK기업은행, AI 불완전판매 탐지 시스템 도입 | sub_block | medium | labor_work | 49.4 |
| Secret tunnels and unregistered workers: China's coal mine disaster is a reminder of darker days | sub_block | medium | energy_climate | 44 |
| Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm | sub_block | medium | ai_tech | 44 |
| Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ | evidence | low | global_conflict | 0 |
