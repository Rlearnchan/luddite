# Jibi Manual Update Summary — 2026-06-01

- Run date: 2026-06-01
- Append mode: `dry_run`
- Target sheet: `Jibi`
- Sheet schema: `bundle_review`
- Append dry-run: True
- Replace existing: False
- Content enrichment status: `succeeded`
- Append status: `dry_run_completed`
- Command status: `success`
- Created at: `2026-06-01T05:56:45.784962+00:00`

## Artifacts

- RSS inbox: `data/inbox/articles/rss_2026-06-01.jsonl`
- Preview CSV: `outputs/daily_digest/2026-06-01_bundle_review_sheet.csv`
- Daily digest: `outputs/daily_digest/2026-06-01.md`
- Quality report: `outputs/reports/jibi_quality_2026-06-01.md`
- Content enrichment report: `outputs/reports/jibi_content_enrichment_2026-06-01.md`
- Content enrichment JSON: `outputs/reports/jibi_content_enrichment_2026-06-01.json`
- Sheet append report: `outputs/reports/jibi_sheet_append_2026-06-01_bundle_review_sheet.md`
- Manual summary JSON: `outputs/reports/jibi_manual_update_2026-06-01.json`

## Logs

- stdout log: `outputs/logs/jibi/jibi_manual_2026-06-01.log`
- stderr log: `outputs/logs/jibi/jibi_manual_2026-06-01.err.log`
