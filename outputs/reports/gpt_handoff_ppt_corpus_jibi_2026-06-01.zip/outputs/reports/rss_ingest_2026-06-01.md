# RSS Ingest Report — 2026-06-01

## Summary

- sources considered: 47
- sources enabled: 13
- sources fetched: 13
- sources skipped: 34
- raw feed items: 797
- unique URLs written: 536
- items written: 536
- duplicate URL appearances: 45
- duplicates skipped: 45
- failures: 0
- output status: `written`
- output preserved reason: ``
- output: `data/inbox/articles/rss_2026-06-01.jsonl`

## Article History

- run_id: `rss_2026-06-01_20260601T0556354`
- previous_run_id: `rss_2026-05-27_20260528T0151360`
- current URLs: 536
- known before: 2533
- known after: 3022
- new to history: 489
- returning known: 47
- previous run URLs: 538
- new since previous run: 489
- dropped since previous run: 491
- percent new since previous run: 91.23%
- percent dropped since previous run: 91.26%
- churn label: `high_churn`
- history ledger: `/Users/bae/Documents/code/luddite/data/candidates/jibi_article_history.jsonl`
- run ledger: `/Users/bae/Documents/code/luddite/data/candidates/jibi_article_runs.jsonl`

### Cadence Recommendation

- recommendation: optional_evening_rss_observation_only
- reason: RSS moving window churn is high; inspect new/dropped examples before changing cadence
- guardrail: do not replace the visible board twice after reviewers start writing

### Source Delta

| source | current | new_to_history | new_since_previous | dropped_since_previous |
| --- | ---: | ---: | ---: | ---: |
| BBC News | 20 | 20 | 20 | 20 |
| NPR | 10 | 10 | 10 | 10 |
| The Conversation | 20 | 12 | 12 | 12 |
| The Guardian Business | 38 | 38 | 38 | 37 |
| The Guardian Environment | 22 | 14 | 14 | 14 |
| The Guardian Technology | 26 | 15 | 15 | 15 |
| 연합뉴스 경제 | 120 | 120 | 120 | 120 |
| 연합뉴스 산업 | 81 | 81 | 81 | 88 |
| 연합뉴스 세계 | 119 | 119 | 119 | 115 |
| 연합인포맥스 | 20 | 20 | 20 | 20 |
| 정책브리핑 | 20 | 20 | 20 | 20 |
| 한국경제 | 20 | 20 | 20 | 20 |
| 한국은행 | 20 | 0 | 0 | 0 |

### New Since Previous Run Examples

- 연합인포맥스 | 2026-06-01 13:05:46 | [여야, 한화에어로 폭발 사고…선거운동 축소·중단](https://news.einfomax.co.kr/news/articleView.html?idxno=4417773)
- 연합인포맥스 | 2026-06-01 13:06:19 | [국고 3년 6.2bp↑…한은 총재 매파 발언·환율 급등에 일제히 약세](https://news.einfomax.co.kr/news/articleView.html?idxno=4417774)
- 연합인포맥스 | 2026-06-01 13:31:00 | [李대통령, 코스피 '반도체 착시' 지적 정면반박 "우리 산업 핵심"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417775)
- 연합인포맥스 | 2026-06-01 13:34:00 | [돈나무 언니, 로빈후드 팔고 방산주 매수](https://news.einfomax.co.kr/news/articleView.html?idxno=4417776)
- 연합인포맥스 | 2026-06-01 13:42:14 | ["美, 레바논과 이스라엘에 새로운 휴전 구상 제안"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417777)
- 연합인포맥스 | 2026-06-01 13:45:36 | [달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원](https://news.einfomax.co.kr/news/articleView.html?idxno=4417778)
- 연합인포맥스 | 2026-06-01 13:48:57 | [미래에셋운용, 글로벌 ETF 순자산 400조 돌파](https://news.einfomax.co.kr/news/articleView.html?idxno=4417779)
- 연합인포맥스 | 2026-06-01 13:54:00 | [대전 한화에어로스페이스 폭발사고…6명 사망·1명 경상](https://news.einfomax.co.kr/news/articleView.html?idxno=4417780)
- 연합인포맥스 | 2026-06-01 14:00:15 | [1분기 기관투자가 외화증권투자 42.6억달러↓…주가조정·금리상승에 평가손실](https://news.einfomax.co.kr/news/articleView.html?idxno=4417781)
- 연합인포맥스 | 2026-06-01 14:02:35 | [산업부, 반도체 성장세에 "올해 수출 1조달러도 가능"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417782)

### Dropped Since Previous Run Examples

- 연합인포맥스 | 2026-05-28 09:45:26 | [BofA "과열된 美 증시…여름 조정에 대비해야"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417082)
- 연합인포맥스 | 2026-05-28 09:45:43 | [[국민성장펀드 연합군] 미래에셋운용 "중소형 성장주 분화직전…자펀드로 투자"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417083)
- 연합인포맥스 | 2026-05-28 09:51:43 | [WTI 선물, 급락 되돌림에 상승…89.84달러·1.31%↑(상보)](https://news.einfomax.co.kr/news/articleView.html?idxno=4417084)
- 연합인포맥스 | 2026-05-28 09:53:33 | [[신윤우의 외환분석] 이란, 금통위 그리고 외국인들](https://news.einfomax.co.kr/news/articleView.html?idxno=4417086)
- 연합인포맥스 | 2026-05-28 09:55:00 | [삼전닉스發 'N% 영업익' 성과 요구 재계 강타…계열사·타업계로 번져](https://news.einfomax.co.kr/news/articleView.html?idxno=4417087)
- 연합인포맥스 | 2026-05-28 10:00:06 | [정청래 "이번 선거, 내란 세력과 내란 극복 국민의 대결"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417089)
- 연합인포맥스 | 2026-05-28 10:02:43 | [기아 EV3, 독일 자동차 전문지 도심형 크로스오버 전기차 평가 '1위'](https://news.einfomax.co.kr/news/articleView.html?idxno=4417090)
- 연합인포맥스 | 2026-05-28 10:03:18 | [김정관 산업장관 "올해 수출 9천억불 넘을 듯…반도체 외에도 숫자 좋아"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417091)
- 연합인포맥스 | 2026-05-28 10:03:16 | [LG엔솔, 美DTE에너지와 16억달러 규모 ESS 공급 계약](https://news.einfomax.co.kr/news/articleView.html?idxno=4417092)
- 연합인포맥스 | 2026-05-28 10:09:03 | ["스페이스X·앤트로픽 초대형 IPO, 대형 기술주 매도 부를 것"](https://news.einfomax.co.kr/news/articleView.html?idxno=4417093)

## Per Source

### manual — Manual Input

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### google_sheet_jibi_candidates — Google Sheet Jibi

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `sheet`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### google_sheet_topic_finding — Google Sheet 주제 찾기

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `sheet`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### reuters_manual — Reuters

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### ap_rss_candidate — Associated Press

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `rss_candidate`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### bbc_rss_candidate — BBC News

- feed_url: `https://feeds.bbci.co.uk/news/rss.xml`
- section_name: ``
- fetch_limit: 
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 36
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Wed, 30 Apr 2025 14:04:28 GMT`
- newest_published_at: `Mon, 01 Jun 2026 05:48:27 GMT`
- sample_titles:
  - Iran and US report new wave of air strikes in Gulf
  - Iran attacks damage 20 US military sites since start of war, satellite images show
  - 'Don't be too kind': Stories from the maternity unit where mums were failed
- skipped_reason: ``
- failure_reason: ``

### guardian_rss_candidate — The Guardian

- feed_url: `https://www.theguardian.com/international/rss`
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### guardian_business — The Guardian Business

- feed_url: `https://www.theguardian.com/business/rss`
- section_name: ``
- fetch_limit: 40
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 38
- items_written: 38
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Thu, 28 May 2026 15:12:30 GMT`
- newest_published_at: `Sun, 31 May 2026 16:30:52 GMT`
- sample_titles:
  - Arm boss in line for billion-dollar payday if chipmaker hits targets
  - Wes Streeting backs calls for national insurance cut and North Sea drilling
  - Disaster of Brexit is a warning against simple solutions to hard problems | Richard Partington
- skipped_reason: ``
- failure_reason: ``

### guardian_technology — The Guardian Technology

- feed_url: `https://www.theguardian.com/technology/rss`
- section_name: ``
- fetch_limit: 40
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 28
- items_written: 26
- duplicate_skipped: 2
- duplicate_examples:
  - Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’ — https://www.theguardian.com/technology/2026/may/30/pope-leo-anthropic-ai
  - Americans echo Pope Leo’s concerns about AI: ‘It threatens workers, privacy and human life’ — https://www.theguardian.com/world/2026/may/30/pope-leo-ai-reaction
- failure_count: 0
- oldest_published_at: `Mon, 16 Mar 2026 07:00:10 GMT`
- newest_published_at: `Sun, 31 May 2026 15:00:51 GMT`
- sample_titles:
  - Anthropic’s alliance with pope on AI harms: all in good faith or ‘Vatican-washing?’
  - An industry targeting Australia’s ageing population is growing, but can AI deliver more humanity in aged care?
  - Anthropic reaches valuation of $965bn, beating OpenAI to become world’s most valuable AI firm
- skipped_reason: ``
- failure_reason: ``

### guardian_environment — The Guardian Environment

- feed_url: `https://www.theguardian.com/environment/rss`
- section_name: ``
- fetch_limit: 40
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 25
- items_written: 22
- duplicate_skipped: 3
- duplicate_examples:
  - The household battery revolution that could change energy bills … and the world — https://www.theguardian.com/environment/ng-interactive/2026/may/31/cheaper-energy-bills-battery-revolution-climate-crisis
  - On-street EV charging in UK is postcode lottery as drivers face council objections — https://www.theguardian.com/environment/2026/may/30/on-street-ev-charging-uk-postcode-lottery-council-objections-gullies-safety-legal-parking
  - The Guardian view on the Aberdeen South byelection: the politics of energy take centre stage | Editorial — https://www.theguardian.com/commentisfree/2026/may/31/the-guardian-view-on-the-aberdeen-south-byelection-the-politics-of-energy-take-centre-stage
- failure_count: 0
- oldest_published_at: `Tue, 19 May 2026 06:00:04 GMT`
- newest_published_at: `Mon, 01 Jun 2026 05:00:08 GMT`
- sample_titles:
  - The household battery revolution that could change energy bills … and the world
  - ‘It’s a great healer’: why being outdoors in nature means so much to us
  - ‘This is a tragedy’: swimming snakes open new front in battle with Balearic lizards
- skipped_reason: ``
- failure_reason: ``

### npr_rss_candidate — NPR

- feed_url: `https://feeds.npr.org/1002/rss.xml`
- section_name: ``
- fetch_limit: 
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 10
- items_written: 10
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Sun, 31 May 2026 05:00:00 -0400`
- newest_published_at: `Sun, 31 May 2026 17:11:19 -0400`
- sample_titles:
  - How aid cuts are hampering the frontline response to the Ebola crisis
  - Trump floats MAGA rally instead of concert after musicians drop out of Freedom 250
  - United Airlines flight to Spain pulls U-turn, apparently over Bluetooth device name
- skipped_reason: ``
- failure_reason: ``

### lemonde_rss_candidate — Le Monde

- feed_url: `https://www.lemonde.fr/rss/une.xml`
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### bloomberg_manual — Bloomberg

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### ft_manual — Financial Times

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### wsj_manual — Wall Street Journal

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### nyt_manual — New York Times

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### economist_manual — The Economist

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### nikkei_asia_manual — Nikkei Asia

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `subscription_manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:subscription_manual`
- failure_reason: ``

### yonhap_rss_candidate — 연합뉴스

- feed_url: `https://www.yna.co.kr/rss/news.xml`
- section_name: `latest`
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### yonhap_international_rss_candidate — 연합뉴스 세계

- feed_url: `https://www.yna.co.kr/rss/international.xml`
- section_name: `international`
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### yonhap_economy — 연합뉴스 경제

- feed_url: `https://www.yna.co.kr/rss/economy.xml`
- section_name: `economy`
- fetch_limit: 120
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 120
- items_written: 120
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Mon, 1 Jun 2026 08:37:41 +0900`
- newest_published_at: `Mon, 1 Jun 2026 14:51:14 +0900`
- sample_titles:
  - '장롱 속 금목걸이 신탁운용' 하나골드신탁, 품목·수익률 확대
  - K푸드, 중국 수출길 넓어진다…등록절차 개선·품목 확대
  - 현대건설·현대엔지니어링 연구조직 'HMG 건설기술연구원' 출범
- skipped_reason: ``
- failure_reason: ``

### yonhap_industry — 연합뉴스 산업

- feed_url: `https://www.yna.co.kr/rss/industry.xml`
- section_name: `industry`
- fetch_limit: 120
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 120
- items_written: 81
- duplicate_skipped: 39
- duplicate_examples:
  - K푸드, 중국 수출길 넓어진다…등록절차 개선·품목 확대 — https://www.yna.co.kr/view/AKR20260601110400017
  - 현대건설·현대엔지니어링 연구조직 'HMG 건설기술연구원' 출범 — https://www.yna.co.kr/view/AKR20260601110500003
  - E1, 6월 LPG 국내 공급가격 인상…프로판·부탄 ㎏당 30원↑ — https://www.yna.co.kr/view/AKR20260601108100003
- failure_count: 0
- oldest_published_at: `Mon, 1 Jun 2026 10:14:01 +0900`
- newest_published_at: `Mon, 1 Jun 2026 14:48:16 +0900`
- sample_titles:
  - [무안소식] 전남농협, 청정축산 우수농가 4곳 시상
  - K푸드, 중국 수출길 넓어진다…등록절차 개선·품목 확대
  - 울산 20대 잠수부 사망사건 하청 대표에 징역 4년 구형
- skipped_reason: ``
- failure_reason: ``

### yonhap_international — 연합뉴스 세계

- feed_url: `https://www.yna.co.kr/rss/international.xml`
- section_name: `international`
- fetch_limit: 120
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 120
- items_written: 119
- duplicate_skipped: 1
- duplicate_examples:
  - [영상] 美북동부 상공서 운석 폭발…"천둥보다 훨씬 큰 폭발음" — https://www.yna.co.kr/view/AKR20260601070600704
- failure_count: 0
- oldest_published_at: `Sun, 31 May 2026 12:49:23 +0900`
- newest_published_at: `Mon, 1 Jun 2026 13:57:53 +0900`
- sample_titles:
  - 버핏 후계 버크셔 CEO, 첫 인수는 美건설업체
  - 미군, 이란 군시설 또 공습…이란 "원점에 보복타격"(종합)
  - [속보] 이란 "미국이 이란영토 타격에 사용한 기지 공격"< AFP>
- skipped_reason: ``
- failure_reason: ``

### yonhap_market — 연합뉴스 마켓+

- feed_url: `https://www.yna.co.kr/rss/market.xml`
- section_name: `market`
- fetch_limit: 120
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### yonhap_health — 연합뉴스 건강

- feed_url: `https://www.yna.co.kr/rss/health.xml`
- section_name: `health`
- fetch_limit: 120
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### infomax_manual — 연합인포맥스

- feed_url: `https://news.einfomax.co.kr/rss/allArticle.xml`
- section_name: ``
- fetch_limit: 
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 50
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `2026-06-01 11:29:07`
- newest_published_at: `2026-06-01 14:46:54`
- sample_titles:
  - IBK기업은행, AI 불완전판매 탐지 시스템 도입
  - 젠슨 황, 휴머노이드 로봇 공개…파트너사는 中 스타트업
  - 군인공제회, 관리부문 이사에 공승배 전 공군군수사령관
- skipped_reason: ``
- failure_reason: ``

### hankyung_manual — 한국경제

- feed_url: `https://www.hankyung.com/feed/all-news`
- section_name: ``
- fetch_limit: 
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 50
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Mon, 01 Jun 2026 11:56:22 +0900`
- newest_published_at: `Mon, 01 Jun 2026 14:04:49 +0900`
- sample_titles:
  - 코스콤 금융사업본부, 'AI 인사이트 데이' 행사 개최
  - MB, 서울숲 깜짝 방문…"일 잘하는 시장 뽑아야"
  - [단독]미코그룹, 유럽 LNG발전 설비업체 넴에너지 인수
- skipped_reason: ``
- failure_reason: ``

### mk_manual — 매일경제

- feed_url: `https://www.mk.co.kr/rss/30000001/`
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### chosunbiz_manual — 조선비즈

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### sedaily_manual — 서울경제

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### joongang_manual — 중앙일보

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### news1_manual — 뉴스1

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### newsis_manual — 뉴시스

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### bok — 한국은행

- feed_url: `https://www.bok.or.kr/portal/bbs/P0002353/news.rss?menuNo=200433`
- section_name: `BOK 이슈노트`
- fetch_limit: 
- collection_enabled: True
- status: `official_release`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 100
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Mon, 19 Jun 2023 14:00:00 +0900`
- newest_published_at: `Thu, 14 May 2026 12:00:00 +0900`
- sample_titles:
  - [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제
  - [제2026-10호｣ 우리나라 주식 자산효과에 대한 평가
  - [제2026-9호] 우리나라 대외부문의 구조적 변화가 환율에 미치는 영향
- skipped_reason: ``
- failure_reason: ``

### kosis — KOSIS/통계청

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### korea_policy_briefing — 정책브리핑

- feed_url: `https://www.korea.kr/rss/pressrelease.xml`
- section_name: `보도자료`
- fetch_limit: 
- collection_enabled: True
- status: `official_release`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 50
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `Mon, 01 Jun 2026 01:58:37 GMT`
- newest_published_at: `Mon, 01 Jun 2026 05:29:59 GMT`
- sample_titles:
  - [법무부]농어촌 외국인 숙련인력 고용 한도 50%로 확대… 외국인 노동자 '부당 이직' 시 이전 경력도 인정
  - [산림청]충주국유림관리소, '소나무재선충병 예찰 역량 강화 교육' 실시
  - [산림청]국내외 산림 과학과 정책 동향, 쉽고 빠르게 전달한다 - 국립산림과학원, 주요 산림 현안과 연구성과 담은 「산림과학브리프」 매월 발간 -
- skipped_reason: ``
- failure_reason: ``

### kma — 기상청

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### world_bank — World Bank

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### imf — IMF

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### oecd — OECD

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### ilo — ILOSTAT

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `official_release`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### the_conversation — The Conversation

- feed_url: `https://theconversation.com/global/articles.atom`
- section_name: ``
- fetch_limit: 
- collection_enabled: True
- status: `rss_verified`
- fetch_status: `fetched`
- parse_status: `parsed`
- item_count: 50
- items_written: 20
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: `2026-05-13T12:14:13Z`
- newest_published_at: `2026-05-29T02:35:01Z`
- sample_titles:
  - Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous
  - Friday essay: How to Sell a Genocide exposes the double standards of reporting on Gaza
  - We analysed 14 million Reddit posts to reveal a striking shift in how we talk about mental health
- skipped_reason: ``
- failure_reason: ``

### atlas_obscura — Atlas Obscura

- feed_url: `https://www.atlasobscura.com/feeds/latest`
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `rss_verified`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

### yougov — YouGov

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### pew — Pew Research

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### gallup — Gallup

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `manual`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `skipped_status:manual`
- failure_reason: ``

### slack_manual — Slack Manual Drop

- feed_url: ``
- section_name: ``
- fetch_limit: 
- collection_enabled: False
- status: `slack`
- fetch_status: `not_fetched`
- parse_status: `not_parsed`
- item_count: 0
- items_written: 0
- duplicate_skipped: 0
- duplicate_examples:
- failure_count: 0
- oldest_published_at: ``
- newest_published_at: ``
- sample_titles:
- skipped_reason: `collection_enabled_false`
- failure_reason: ``

## Failures

- none
