# Jibi Content Enrichment Review — 2026-06-01

## Summary

- selected_candidates: 20
- top_selected: 10
- near_miss_selected: 10
- enrichment_not_attempted: 16
- enrichment_ok: 3
- enrichment_blocked: 0
- enrichment_paywalled_or_teaser: 0
- enrichment_empty: 1
- enrichment_error: 0

## Source Status Summary

| source | selected | not_attempted | ok | blocked | paywalled_or_teaser | empty | error | dominant_method |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| BBC News | 1 | 0 | 1 | 0 | 0 | 0 | 0 | bbc_next_data_text |
| The Conversation | 1 | 1 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| The Guardian Business | 2 | 2 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| The Guardian Environment | 1 | 1 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| The Guardian Technology | 2 | 2 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| 연합뉴스 경제 | 3 | 3 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| 연합뉴스 세계 | 3 | 3 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| 연합인포맥스 | 3 | 0 | 2 | 0 | 0 | 1 | 0 | infomax_article_view_content |
| 정책브리핑 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | unsupported_source |
| 한국은행 | 3 | 3 | 0 | 0 | 0 | 0 | 0 | unsupported_source |

## Candidate Enrichment Table

| role | title | source | status | method | body_chars | paragraphs | meta_description_chars | reason |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- |
| top | The household battery revolution that could change energy bills … and the world | The Guardian Business | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | 네이버, 드론 스타트업 유비파이 투자…피지컬 AI 본격화 | 연합뉴스 경제 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | [제2026-3호] '쉬었음' 청년층의 특징 및 평가: 미취업 유형별 비교 분석 | 한국은행 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | [제2026-11호] 국내외 자산 토큰화 현황 및 향후 정책 과제 | 한국은행 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | 춘천시, 공사장 AI 안전관리 도입…중대재해 예방 기대 | 연합뉴스 경제 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | 송치영 "소상공인 생존권 위기"…고용정책 전환 촉구 | 연합뉴스 경제 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | [제2026-8호] 남성 청년층 경제활동참가율의 하락 추세 평가 | 한국은행 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | ‘That’s why we work in finance – so one day we can afford air-con’: Britain’s unequal heatwave | The Guardian Business | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | Too hot, too humid: why the sustained heatwave in India and Pakistan is so dangerous | The Conversation | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| top | Air conditioning: the wealthy and well can afford it, but disabled people who need it most can't \| Frances Ryan | The Guardian Environment | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | ok | infomax_article_view_content | 1169 | 13 | 299 |  |
| near_miss | IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | ok | infomax_article_view_content | 494 | 6 | 299 |  |
| near_miss | 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | empty | infomax_article_view_content | 0 | 0 | 0 | no_extractable_article_body |
| near_miss | "석유보다 비싼 메모리칩"…빅3 시총이 오일 빅3 웃돈다 | 연합뉴스 세계 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | ‘Hidden datacentre tax’ costing Irish households millions, report says | The Guardian Technology | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | Samsung memory chip staff in line for £310,000 bonuses after AI profit-sharing deal | The Guardian Technology | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | 日, 美 '제네시스 미션' 참여…5년간 AI분야 7천500억원 투자 | 연합뉴스 세계 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | 대만, 올해 성장률 전망치 9.64%로 상향…16년만에 최고 예상 | 연합뉴스 세계 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | [방위사업청]레이저대공무기 '천광' 핵심 구성품(레이저발진기) 국산화 성공 | 정책브리핑 | not_attempted | unsupported_source | 0 | 0 | 0 | unsupported_source |
| near_miss | Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | ok | bbc_next_data_text | 4295 | 30 | 117 |  |

## RSS-only vs Enriched What-if Scoring

| role | title | source | status | score_delta | action_delta | grade_delta | resolved | remaining_gate_reasons |
| --- | --- | --- | --- | ---: | --- | --- | --- | --- |
| near_miss | 산업부, 반도체 성장세에 "올해 수출 1조달러도 가능" | 연합인포맥스 | ok | -76.0 | gather_more_evidence -> editorial_review | A -> D | disqualifying_details_found | single_company_without_broader_bridge |
| near_miss | IBK기업은행, AI 불완전판매 탐지 시스템 도입 | 연합인포맥스 | ok | 0.0 | gather_more_evidence -> gather_more_evidence | B -> B | none | generic_why_for_unspecific_seed_type |
| near_miss | 달러-원, 커스터디 달러 매수에 10원 이상 급등…한때 1,518.00원 | 연합인포맥스 | empty | None | gather_more_evidence -> None | B -> None | disqualifying_details_found | none |
| near_miss | Put a £5 deposit on vapes to stop littering, say waste companies | BBC News | ok | 0.0 | gather_more_evidence -> gather_more_evidence | B -> B | none | generic_why_for_unspecific_seed_type |

## Copyright / Storage Note

No full article bodies are printed or committed. Enrichment is used only for derived diagnostics.
